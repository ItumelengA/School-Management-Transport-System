
import java.io.File;
import java.io.FileOutputStream;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import static java.awt.print.Printable.NO_SUCH_PAGE;
import static java.awt.print.Printable.PAGE_EXISTS;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.print.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class reports extends javax.swing.JPanel {

    public reports() {
        initComponents();
        cmbReport_Type.addItem("-- Select report type -- ");
        cmbReport_Type.addItem("Monthly Booking Summary");
        cmbReport_Type.addItem("Parent/Learner Directory");
        cmbReport_Type.addItem("Financial summary");

        lblReport_Type.setText((String) cmbReport_Type.getSelectedItem());

        cmbReport_Type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {

                String selectedItem = (String) cmbReport_Type.getSelectedItem();
                lblReport_Type.setText(selectedItem);
            }
        });
        // Add action listener for Generate Reports button
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                String selectedReport = (String) cmbReport_Type.getSelectedItem();
                generateReport(selectedReport);
                retrieveSystemInfor(); // Update the stats
            }
        });
        retrieveSystemInfor();
    }
// Method to generate reports based on selected type

    public void generateReport(String reportType) {
        switch (reportType) {
            case "Monthly Booking Summary":
                loadBookingSummary();
                break;
            case "Booking Status Report":
                loadBookingStatusReport();
                break;
            case "Financial summary":
                loadFinancialSummary();
                break;
            case "Parent/Learner Directory":
                loadParentLearnerDirectory();
                break;
            default:
                JOptionPane.showMessageDialog(null, "Please select a valid report type");
        }
    }

    private void loadBookingSummary() {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseHelper.getConnection();
            stmt = conn.createStatement();

            String query = "SELECT Arrangement_ID, CONCAT(Parent_Name, ' ', Parent_Surname) AS Parent_Name, "
                    + "CONCAT(Learner_Name, ' ', Learner_Surname) AS Learner_Name, "
                    + "School_Name, Pickup_Location, CONCAT(Driver_Name, ' ', Driver_Surname) AS Driver_Name "
                    + "FROM Arrangement ORDER BY Arrangement_Date DESC";

            rs = stmt.executeQuery(query);

            // Create table model
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Arrangement ID");
            model.addColumn("Parent Name");
            model.addColumn("Learner Name");
            model.addColumn("School Name");
            model.addColumn("Pickup");
            model.addColumn("Driver");

            // Populate table
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("Arrangement_ID"),
                    rs.getString("Parent_Name"),
                    rs.getString("Learner_Name"),
                    rs.getString("School_Name"),
                    rs.getString("Pickup_Location"),
                    rs.getString("Driver_Name")
                });
            }

            jTable1.setModel(model);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error loading booking summary: " + e.getMessage());
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

// 2. Booking Status Report
    private void loadBookingStatusReport() {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseHelper.getConnection();
            stmt = conn.createStatement();

            String query = "SELECT Arrangement_ID, CONCAT(Parent_Name, ' ', Parent_Surname) AS Parent_Name, "
                    + "CONCAT(Learner_Name, ' ', Learner_Surname) AS Learner_Name, "
                    + "School_Name, Status, Arrangement_Date "
                    + "FROM Arrangement ORDER BY Arrangement_Date DESC";

            rs = stmt.executeQuery(query);

            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Arrangement ID");
            model.addColumn("Parent Name");
            model.addColumn("Learner Name");
            model.addColumn("School Name");
            model.addColumn("Status");
            model.addColumn("Date");

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("Arrangement_ID"),
                    rs.getString("Parent_Name"),
                    rs.getString("Learner_Name"),
                    rs.getString("School_Name"),
                    rs.getString("Status"),
                    rs.getDate("Arrangement_Date")
                });
            }

            jTable1.setModel(model);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error loading booking status: " + e.getMessage());
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

// 3. Financial Summary
    private void loadFinancialSummary() {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseHelper.getConnection();
            stmt = conn.createStatement();

           String query = "SELECT 'Total Payments' AS Category, " +
               "SUM(Amount_R) AS Amount, " +
               "COUNT(DISTINCT Parent_ID) AS Count, " +
               "CASE WHEN COUNT(DISTINCT Parent_ID) > 0 THEN SUM(Amount_R) / COUNT(DISTINCT Parent_ID) ELSE 0 END AS Average " +
               "FROM Payment " +
               "UNION ALL " +
               "SELECT School_name AS Category, " +
               "SUM(Amount_R) AS Amount, " +
               "COUNT(*) AS Count, " +
               "CASE WHEN COUNT(*) > 0 THEN SUM(Amount_R) / COUNT(*) ELSE 0 END AS Average " +
               "FROM Payment GROUP BY School_name";

            rs = stmt.executeQuery(query);

            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Category");
            model.addColumn("Amount (R)");
            model.addColumn("Count");
            model.addColumn("Average (R)");

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("Category"),
                    String.format("R %.2f", rs.getDouble("Amount")),
                    rs.getInt("Count"),
                    String.format("R %.2f", rs.getDouble("Average"))
                });
            }

            jTable1.setModel(model);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error loading financial summary: " + e.getMessage());
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

// 4. Parent/Learner Directory
    private void loadParentLearnerDirectory() {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseHelper.getConnection();
            stmt = conn.createStatement();

            String query = "SELECT CONCAT(p.Name, ' ', p.Surname) AS Parent_Name, "
                    + "p.Phone_number AS Contact, "
                    + "CONCAT(l.Name, ' ', l.Surname) AS Student_Name, "
                    + "l.Age AS Grade, "
                    + "COALESCE(pay.Amount_R, 0) AS Transport_Fee "
                    + "FROM Parent p "
                    + "INNER JOIN Learner l ON p.Parent_ID = l.Parent_ID "
                    + "LEFT JOIN Payment pay ON p.Parent_ID = pay.Parent_ID "
                    + "ORDER BY p.Surname";

            rs = stmt.executeQuery(query);

            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Parent Name");
            model.addColumn("Contact");
            model.addColumn("Student Name");
            model.addColumn("Learner Age");
            model.addColumn("Transport Fee (R)");

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("Parent_Name"),
                    rs.getString("Contact"),
                    rs.getString("Student_Name"),
                    rs.getInt("Grade"),
                    String.format("R %.2f", rs.getDouble("Transport_Fee"))
                });
            }

            jTable1.setModel(model);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error loading parent/learner directory: " + e.getMessage());
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

// Helper method to close resources
    private void closeResources(Connection conn, Statement stmt, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error closing resources: " + e.getMessage());
        }
    }

    public void retrieveSystemInfor() {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            // Establish connection
            conn = DatabaseHelper.getConnection();
            stmt = conn.createStatement();

            // Query to get the total number of accounts
            String totalAccountsQuery = "SELECT COUNT(*) AS total_accounts FROM Login";
            rs = stmt.executeQuery(totalAccountsQuery);
            rs.next();
            int totalAccounts = rs.getInt("total_accounts");

            // Query to get the total number of arrangements
            String arrangementString = "SELECT COUNT(*) AS arrangements "
                    + "FROM Arrangement";

            rs = stmt.executeQuery(arrangementString);
            rs.next();
            int totalArrangements = rs.getInt("arrangements");

            // Query to get the total number of pending drivers
            String pendingDriversQuery = "SELECT COUNT(*) AS pending_drivers FROM Transport WHERE Status = 'pending'";
            rs = stmt.executeQuery(pendingDriversQuery);
            rs.next();
            int totalPendingDrivers = rs.getInt("pending_drivers");

            // Query to get the total number of rejected drivers
            String rejectedDriversQuery = "SELECT COUNT(*) AS rejected_drivers FROM Transport WHERE Status = 'rejected'";
            rs = stmt.executeQuery(rejectedDriversQuery);
            rs.next();
            int totalRejectedDrivers = rs.getInt("rejected_drivers");

            // Query to get the total number of approved drivers
            String approvedDriversQuery = "SELECT COUNT(*) AS approved_drivers FROM Transport WHERE Status = 'approved'";
            rs = stmt.executeQuery(approvedDriversQuery);
            rs.next();
            int totalApprovedDrivers = rs.getInt("approved_drivers");

            lblTotalAccounts.setText(String.valueOf(totalAccounts));
            lblTotalArrangements.setText(String.valueOf(totalArrangements));
            lblRejectedDrivers.setText(String.valueOf(totalRejectedDrivers));
            lblApproveDrivers.setText(String.valueOf(totalApprovedDrivers));
            lblPendingDocuments.setText(String.valueOf(totalPendingDrivers));
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            lblDate.setText(today.format(formatter));

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error retrieving data: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error closing resources: " + e.getMessage());
            }
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        lblReport_Type = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lblDate = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        lblTotalAccounts = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        lblTotalArrangements = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        lblPendingDocuments = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lblRejectedDrivers = new javax.swing.JLabel();
        lblApproveDrivers = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cmbReport_Type = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Report Display", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SansSerif", 1, 12))); // NOI18N

        jPanel3.setBackground(new java.awt.Color(0, 102, 204));

        lblReport_Type.setFont(new java.awt.Font("Corbel", 1, 24)); // NOI18N
        lblReport_Type.setForeground(new java.awt.Color(255, 255, 255));
        lblReport_Type.setText("Monthly Booking Summary");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Date:");

        lblDate.setFont(new java.awt.Font("Yu Gothic Medium", 0, 12)); // NOI18N
        lblDate.setForeground(new java.awt.Color(255, 255, 255));
        lblDate.setText("--");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(lblReport_Type)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblDate, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5)
                        .addComponent(lblDate))
                    .addComponent(lblReport_Type))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(0, 153, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Total accounts");

        lblTotalAccounts.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lblTotalAccounts.setForeground(new java.awt.Color(255, 255, 255));
        lblTotalAccounts.setText("-");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTotalAccounts)
                    .addComponent(jLabel7))
                .addContainerGap(104, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTotalAccounts)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(0, 204, 102));

        jLabel8.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Total arrangements");

        lblTotalArrangements.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lblTotalArrangements.setForeground(new java.awt.Color(255, 255, 255));
        lblTotalArrangements.setText("-");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTotalArrangements)
                    .addComponent(jLabel8))
                .addContainerGap(87, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTotalArrangements)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(255, 204, 0));

        jLabel9.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Pending drivers");

        lblPendingDocuments.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lblPendingDocuments.setForeground(new java.awt.Color(255, 255, 255));
        lblPendingDocuments.setText("-");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPendingDocuments)
                    .addComponent(jLabel9))
                .addContainerGap(88, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblPendingDocuments)
                .addContainerGap())
        );

        jPanel7.setBackground(new java.awt.Color(255, 102, 102));

        jLabel10.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Rejected drivers:");

        jLabel11.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Approved drivers:");

        lblRejectedDrivers.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lblRejectedDrivers.setForeground(new java.awt.Color(255, 255, 255));
        lblRejectedDrivers.setText("-");

        lblApproveDrivers.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lblApproveDrivers.setForeground(new java.awt.Color(255, 255, 255));
        lblApproveDrivers.setText("-");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblRejectedDrivers))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblApproveDrivers)))
                .addContainerGap(57, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(lblRejectedDrivers))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(lblApproveDrivers))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(81, 81, 81)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(74, 74, 74)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Report Selection"));

        jLabel1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 255));
        jLabel1.setText("Transport Management System");

        jLabel2.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel2.setText("Select Report Type:");

        jLabel3.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 153, 153));
        jLabel3.setText("Admin panel");

        jButton1.setBackground(new java.awt.Color(0, 102, 204));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Generate reports");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmbReport_Type, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(57, 57, 57)
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel3))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(cmbReport_Type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addComponent(jButton1))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbReport_Type;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblApproveDrivers;
    private javax.swing.JLabel lblDate;
    private javax.swing.JLabel lblPendingDocuments;
    private javax.swing.JLabel lblRejectedDrivers;
    private javax.swing.JLabel lblReport_Type;
    private javax.swing.JLabel lblTotalAccounts;
    private javax.swing.JLabel lblTotalArrangements;
    // End of variables declaration//GEN-END:variables
}
