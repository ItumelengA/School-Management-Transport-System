
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.BorderFactory;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class RejectedDocuments extends javax.swing.JPanel {

    private JPanel selectedCard = null;
    private String selectedDriverName = null;
    private int selectedDriverId = -1;

    public RejectedDocuments() {
        initComponents();

        load_rejected_documents();
    }

    private void load_rejected_documents() {
        try (Connection con = DatabaseHelper.getConnection()) {
            String sql = "SELECT t.Transport_ID, d.Driver_ID, d.Name, d.Surname, "
                    + "t.pdf_name,t.License_pdf, t.License_number, t.Vehicle_make, t.Vehicle_model, t.Vehicle_registration, t.Status,t.Rejected_reason "
                    + "FROM Transport t "
                    + "JOIN driver_registrations d ON t.Driver_ID = d.Driver_ID "
                    + "WHERE t.Status = 'Rejected'";

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                try (ResultSet rs = ps.executeQuery()) {
                    buildCards(rs);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void buildCards(ResultSet rs) throws Exception {
        cardPanel.removeAll();
        cardPanel.setLayout(new BoxLayout(cardPanel, BoxLayout.Y_AXIS));

        boolean hasResults = false;

        while (rs.next()) {
            hasResults = true;
            int driverId = rs.getInt("Driver_ID");
            String name = rs.getString("Name");
            String surname = rs.getString("Surname");

            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(180, 180, 180), 1),
                    BorderFactory.createEmptyBorder(10, 10, 10, 10)
            ));
            panel.setBackground(Color.WHITE);
            panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 160));

            // Basic info labels
            JLabel lblName = new JLabel("Driver: " + rs.getString("Name") + " " + rs.getString("Surname"));
            JLabel lblVehicle = new JLabel("Vehicle: " + rs.getString("Vehicle_make") + " " + rs.getString("Vehicle_model"));
            JLabel lblReg = new JLabel("Registration: " + rs.getString("Vehicle_registration"));
            JLabel lblLicense = new JLabel("License No: " + rs.getString("License_number"));

            String rejectedReason = rs.getString("Rejected_reason");
            JLabel lblRejectedReason = new JLabel("Reason: " + (rejectedReason != null ? rejectedReason : "Not specified"));
            lblRejectedReason.setForeground(Color.RED);
            lblRejectedReason.setFont(lblRejectedReason.getFont().deriveFont(Font.ITALIC, 13f));

            // Slight spacing between labels
            lblName.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
            lblVehicle.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
            lblReg.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
            lblLicense.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
            lblRejectedReason.setBorder(BorderFactory.createEmptyBorder(4, 0, 2, 0));

            // Add all labels
            panel.add(lblName);
            panel.add(lblVehicle);
            panel.add(lblReg);
            panel.add(lblLicense);
            panel.add(lblRejectedReason);

            // Highlight selection on click
            panel.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseClicked(java.awt.event.MouseEvent e) {
                    // Set the selected driver ID
                    selectedDriverId = driverId;
                    selectedDriverName = name + " " + surname;

                    // Reset previous selection
                    if (selectedCard != null) {
                        selectedCard.setBackground(Color.WHITE);
                        selectedCard.setBorder(BorderFactory.createCompoundBorder(
                                BorderFactory.createLineBorder(new Color(180, 180, 180), 1),
                                BorderFactory.createEmptyBorder(10, 10, 10, 10)
                        ));
                    }

                    // Highlight selected card
                    panel.setBackground(new Color(200, 230, 255));
                    panel.setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(new Color(0, 51, 102), 2),
                            BorderFactory.createEmptyBorder(9, 9, 9, 9)
                    ));
                    selectedCard = panel;
                }
            });

            cardPanel.add(panel);
            cardPanel.add(new JLabel(" ")); // spacing between cards
        }

        if (!hasResults) {
            JLabel noDocsLabel = new JLabel("No rejected documents found", SwingConstants.CENTER);
            noDocsLabel.setFont(new Font("Segoe UI", Font.ITALIC, 16));
            noDocsLabel.setForeground(Color.GRAY);

            cardPanel.setLayout(new BorderLayout());
            cardPanel.add(noDocsLabel, BorderLayout.CENTER);
        }

        cardPanel.revalidate();
        cardPanel.repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnSearch = new javax.swing.JButton();
        txtSearch = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        cardPanel = new javax.swing.JPanel();
        btnRequestReupload = new javax.swing.JButton();
        btnViewFile = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnSearch.setBackground(new java.awt.Color(0, 51, 102));
        btnSearch.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/search_2.png"))); // NOI18N
        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });
        add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 40, 100, 30));

        txtSearch.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        add(txtSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 40, 380, 30));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        cardPanel.setBackground(new java.awt.Color(255, 255, 255));
        cardPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cardPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jScrollPane1.setViewportView(cardPanel);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, 900, 360));

        btnRequestReupload.setBackground(new java.awt.Color(0, 51, 102));
        btnRequestReupload.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnRequestReupload.setForeground(new java.awt.Color(255, 255, 255));
        btnRequestReupload.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/request_upload.png"))); // NOI18N
        btnRequestReupload.setText("Request Re-Upload");
        btnRequestReupload.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRequestReuploadActionPerformed(evt);
            }
        });
        add(btnRequestReupload, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 460, -1, -1));

        btnViewFile.setBackground(new java.awt.Color(0, 153, 0));
        btnViewFile.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnViewFile.setForeground(new java.awt.Color(255, 255, 255));
        btnViewFile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/revi.png"))); // NOI18N
        btnViewFile.setText("View Document");
        btnViewFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewFileActionPerformed(evt);
            }
        });
        add(btnViewFile, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 460, 150, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        // Check if search text is empty
        String searchText = (txtSearch != null ? txtSearch.getText().trim() : "");

        if (searchText.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a search input!",
                    "No Input",
                    JOptionPane.WARNING_MESSAGE);
            if (txtSearch != null) {
                txtSearch.requestFocus();
            }
            return;
        }
        loadRejectedDocumentsWithSearch(searchText);
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnRequestReuploadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRequestReuploadActionPerformed

    }//GEN-LAST:event_btnRequestReuploadActionPerformed
    private void loadRejectedDocumentsWithSearch(String searchText) {
        try (Connection con = DatabaseHelper.getConnection()) {
            String sql = "SELECT t.Transport_ID, d.Driver_ID, d.Name, d.Surname, "
                    + "t.pdf_name,t.License_pdf, t.License_number, t.Vehicle_make, t.Vehicle_model, t.Vehicle_registration, t.Status,t.Rejected_reason "
                    + "FROM Transport t "
                    + "JOIN driver_registrations d ON t.Driver_ID = d.Driver_ID "
                    + "WHERE t.Status = 'Rejected'";

            if (searchText != null && !searchText.trim().isEmpty()) {
                sql += " AND (d.Name LIKE ? OR d.Surname LIKE ?)";
            }

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                if (searchText != null && !searchText.trim().isEmpty()) {
                    String sText = "%" + searchText.trim() + "%";
                    ps.setString(1, sText);
                    ps.setString(2, sText);
                }

                try (ResultSet rs = ps.executeQuery()) {
                    buildCards(rs);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void btnViewFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewFileActionPerformed
        if (selectedDriverId == -1) {
            JOptionPane.showMessageDialog(this,
                    "Please select a driver from the list first.",
                    "No Selection",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseHelper.getConnection()) {
            String sql = "SELECT pdf_name, License_pdf FROM Transport WHERE Driver_ID = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, selectedDriverId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String pdfName = rs.getString("pdf_name");
                Blob pdfBlob = rs.getBlob("License_pdf");

                if (pdfBlob == null) {
                    JOptionPane.showMessageDialog(this,
                            "No PDF file found for this driver.",
                            "File Not Found",
                            JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Create temp file
                File pdfFile = new File(System.getProperty("java.io.tmpdir"), pdfName);

                // Write blob to file
                try (InputStream in = pdfBlob.getBinaryStream(); FileOutputStream out = new FileOutputStream(pdfFile)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = in.read(buffer)) != -1) {
                        out.write(buffer, 0, bytesRead);
                    }
                }

                // Open the PDF file
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(pdfFile);
                } else {
                    JOptionPane.showMessageDialog(this,
                            "Cannot open PDF. Desktop operations not supported.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this,
                        "File not found for selected driver.",
                        "Not Found",
                        JOptionPane.WARNING_MESSAGE);
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Error opening file: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnViewFileActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRequestReupload;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnViewFile;
    private javax.swing.JPanel cardPanel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
