
import javax.swing.JOptionPane;

public class D_dashboard extends javax.swing.JFrame {

    private Driver loggedInDriver;

    public D_dashboard() {
        initComponents();
        d_registration panel = new d_registration();
        panel.setLoggedInDriver(loggedInDriver);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        lbl_child_overview = new javax.swing.JLabel();
        lblContactParent = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lblPayment = new javax.swing.JLabel();
        lblLogout = new javax.swing.JLabel();
        lblProfile = new javax.swing.JLabel();
        lblReviews = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jDesktopPane1 = new javax.swing.JDesktopPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(0, 51, 102));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Segoe UI Symbol", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("School Ride | © 2025 | Follow us on Twitter @SchoolRideApp");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(379, 9, -1, -1));

        jLabel17.setFont(new java.awt.Font("Britannic Bold", 0, 14)); // NOI18N
        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/bus_logo.png"))); // NOI18N
        jLabel17.setText("SAFE RIDES");

        jPanel4.setBackground(new java.awt.Color(0, 19, 34));

        lbl_child_overview.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lbl_child_overview.setForeground(new java.awt.Color(255, 255, 255));
        lbl_child_overview.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lbl_child_overview.setText("Children overview");
        lbl_child_overview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lbl_child_overview.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_child_overviewMouseClicked(evt);
            }
        });

        lblContactParent.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lblContactParent.setForeground(new java.awt.Color(255, 255, 255));
        lblContactParent.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblContactParent.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/contact.png"))); // NOI18N
        lblContactParent.setText("Contact parent");
        lblContactParent.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblContactParent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblContactParentMouseClicked(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N
        jLabel4.setText("menu");

        lblPayment.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lblPayment.setForeground(new java.awt.Color(255, 255, 255));
        lblPayment.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblPayment.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/payment.png"))); // NOI18N
        lblPayment.setText("Payment");
        lblPayment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblPayment.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPaymentMouseClicked(evt);
            }
        });

        lblLogout.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lblLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblLogout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/logout.png"))); // NOI18N
        lblLogout.setText("Logout");
        lblLogout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLogoutMouseClicked(evt);
            }
        });

        lblProfile.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lblProfile.setForeground(new java.awt.Color(255, 255, 255));
        lblProfile.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblProfile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/profile_image.png"))); // NOI18N
        lblProfile.setText("Profile");
        lblProfile.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblProfile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblProfileMouseClicked(evt);
            }
        });

        lblReviews.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lblReviews.setForeground(new java.awt.Color(255, 255, 255));
        lblReviews.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblReviews.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/reviews.png"))); // NOI18N
        lblReviews.setText("Reviews");
        lblReviews.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblReviews.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblReviewsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jSeparator1)
                        .addContainerGap())
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jSeparator2)
                        .addGap(28, 28, 28))))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblContactParent, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbl_child_overview, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(8, 8, 8))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblProfile, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblReviews, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 46, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbl_child_overview, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblContactParent, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(83, 83, 83)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(lblProfile, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(lblReviews, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1130, Short.MAX_VALUE)
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 590, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1380, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 688, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void setLoggedInDriver(Driver driver) {
        this.loggedInDriver = driver;
        showRegistrationPanel();
    }

    public void showRegistrationPanel() {
        jDesktopPane1.removeAll();
        d_registration panel = new d_registration();
        panel.setLoggedInDriver(loggedInDriver);
        panel.setBounds(0, 0, jDesktopPane1.getWidth(), jDesktopPane1.getHeight());
        jDesktopPane1.add(panel);
        jDesktopPane1.revalidate();
        jDesktopPane1.repaint();
        panel.setVisible(true);

    }
    private void lbl_child_overviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_child_overviewMouseClicked

        jDesktopPane1.removeAll();

        d_childOverview panel = new d_childOverview(loggedInDriver);
        panel.setLoggedInDriver(loggedInDriver);

        panel.setSize(jDesktopPane1.getSize());
        panel.setLocation(0, 0);

        jDesktopPane1.add(panel);
        panel.setVisible(true);
        jDesktopPane1.revalidate();
        jDesktopPane1.repaint();
    }//GEN-LAST:event_lbl_child_overviewMouseClicked

    private void lblContactParentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblContactParentMouseClicked
        jDesktopPane1.removeAll();
        d_contact panel = new d_contact();
        panel.setBounds(0, 0, jDesktopPane1.getWidth(), jDesktopPane1.getHeight());
        jDesktopPane1.add(panel);
        jDesktopPane1.revalidate();
        jDesktopPane1.repaint();
    }//GEN-LAST:event_lblContactParentMouseClicked

    private void lblPaymentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPaymentMouseClicked
        jDesktopPane1.removeAll();
        d_payment_history panel = new d_payment_history(loggedInDriver);
        panel.setLoggedInDriver(loggedInDriver);
        panel.setBounds(0, 0, jDesktopPane1.getWidth(), jDesktopPane1.getHeight());
        jDesktopPane1.add(panel);
        jDesktopPane1.revalidate();
        jDesktopPane1.repaint();
        panel.setVisible(true);
    }//GEN-LAST:event_lblPaymentMouseClicked

    private void lblLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLogoutMouseClicked

        logout();
    }

    private void logout() {
        // Ask for confirmation before logging out (optional)
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?",
                "Logout",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            // Clear logged-in parent info
            loggedInDriver = null;

            // Close current dashboard
            dispose();

            Login loginForm = new Login();  // ✅ Correct class name
            loginForm.setVisible(true);
            loginForm.setLocationRelativeTo(null); // center on screen
        }
    }//GEN-LAST:event_lblLogoutMouseClicked

    private void lblProfileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProfileMouseClicked
        jDesktopPane1.removeAll();
        DriverProfile panel = new DriverProfile(loggedInDriver.getLoginId());
        panel.setLoggedInDriver(loggedInDriver);
        panel.setBounds(0, 0, jDesktopPane1.getWidth(), jDesktopPane1.getHeight());
        jDesktopPane1.add(panel);
        jDesktopPane1.revalidate();
        jDesktopPane1.repaint();
        panel.setVisible(true);
    }//GEN-LAST:event_lblProfileMouseClicked

    private void lblReviewsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblReviewsMouseClicked
        jDesktopPane1.removeAll();
        DriverReviews panel = new DriverReviews();

        panel.setBounds(0, 0, jDesktopPane1.getWidth(), jDesktopPane1.getHeight());
        jDesktopPane1.add(panel);
        jDesktopPane1.revalidate();
        jDesktopPane1.repaint();
        panel.setVisible(true);
    }//GEN-LAST:event_lblReviewsMouseClicked

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new D_dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lblContactParent;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JLabel lblPayment;
    private javax.swing.JLabel lblProfile;
    private javax.swing.JLabel lblReviews;
    private javax.swing.JLabel lbl_child_overview;
    // End of variables declaration//GEN-END:variables
}
