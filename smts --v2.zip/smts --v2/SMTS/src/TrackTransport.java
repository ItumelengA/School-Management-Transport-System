
import javax.swing.*;
import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.Line2D;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;
import java.util.List;
import javax.swing.event.MouseInputListener;
import org.jxmapviewer.OSMTileFactoryInfo;
import org.jxmapviewer.VirtualEarthTileFactoryInfo;
import org.jxmapviewer.input.PanMouseInputListener;
import org.jxmapviewer.input.ZoomMouseWheelListenerCenter;
import org.jxmapviewer.viewer.DefaultTileFactory;
import org.jxmapviewer.viewer.GeoPosition;
import org.jxmapviewer.viewer.TileFactoryInfo;
import org.jxmapviewer.viewer.WaypointPainter;
import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.painter.CompoundPainter;
import org.jxmapviewer.painter.Painter;
import org.json.JSONObject;
import org.json.JSONArray;
import waypoint.EventWaypoint;
import waypoint.MyWaypoint;
import waypoint.WaypointRender;

public class TrackTransport extends javax.swing.JPanel {

   // BulkSMS Configuration
    private static final String BULK_SMS_URL = "https://api.bulksms.com/v1/messages";
    private static final String USERNAME = "boago";
    private static final String PASSWORD = "Spu@2004";
    
    // Default to Kimberley, South Africa
    private double PARENT_LAT = -28.7282323;
    private double PARENT_LON = 24.7499794;
    
    private JXMapViewer jXMapViewer;
    private final Set<MyWaypoint> waypoints = new HashSet<>();
    private EventWaypoint event;
    
    // Store logged-in parent information
    private Object loggedInParent;
    
    // Store current route coordinates
    private List<GeoPosition> routeCoordinates = new ArrayList<>();
    
    // Store current driver info for SMS
    private String currentDriverName = "";
    private String currentDriverPhone = "";
    private int currentDriverId = -1;

    public TrackTransport() {

        initComponents();
        initMap();
        loadDrivers();
        addParentWaypoint();

    }

    // ===================== SET LOGGED-IN PARENT =====================
    public void setLoggedInParent(Object parent) {
        this.loggedInParent = parent;
        loadParentLocation();
    }
    
    // ===================== LOAD PARENT LOCATION FROM DATABASE =====================
    private void loadParentLocation() {
        // TODO: Implement database query to get parent's actual location
        PARENT_LAT = -28.7282323;
        PARENT_LON = 24.7499794;
        
        addParentWaypoint();
        jXMapViewer.setAddressLocation(new GeoPosition(PARENT_LAT, PARENT_LON));
    }

    // ===================== INITIALIZE MAP =====================
    private void initMap() {
        jXMapViewer = new JXMapViewer();
        
        TileFactoryInfo info = new OSMTileFactoryInfo();
        DefaultTileFactory tileFactory = new DefaultTileFactory(info);
        jXMapViewer.setTileFactory(tileFactory);
        
        GeoPosition parentGeo = new GeoPosition(PARENT_LAT, PARENT_LON);
        jXMapViewer.setAddressLocation(parentGeo);
        jXMapViewer.setZoom(7);
        
        MouseInputListener mm = new PanMouseInputListener(jXMapViewer);
        jXMapViewer.addMouseListener(mm);
        jXMapViewer.addMouseMotionListener(mm);
        jXMapViewer.addMouseWheelListener(new ZoomMouseWheelListenerCenter(jXMapViewer));
        
        mapPanel.setLayout(new BorderLayout());
        mapPanel.add(jXMapViewer, BorderLayout.CENTER);
        
        event = getEvent();
    }

    // ===================== ADD PARENT WAYPOINT =====================
    private void addParentWaypoint() {
        clearWaypoints();
        MyWaypoint parentWaypoint = new MyWaypoint(
            "Parent Location (Kimberley)", 
            event, 
            new GeoPosition(PARENT_LAT, PARENT_LON)
        );
        waypoints.add(parentWaypoint);
        updateWaypoints();
    }

    // ===================== UPDATE WAYPOINTS =====================
    private void updateWaypoints() {
        for (MyWaypoint wp : waypoints) {
            jXMapViewer.remove(wp.getButton());
        }
        
        List<Painter<JXMapViewer>> painters = new ArrayList<>();
        
        // Add route painter if we have route coordinates
        if (!routeCoordinates.isEmpty()) {
            painters.add(new RoutePainter());
        }
        
        // Add waypoint painter
        WaypointPainter<MyWaypoint> waypointPainter = new WaypointRender();
        waypointPainter.setWaypoints(waypoints);
        painters.add(waypointPainter);
        
        CompoundPainter<JXMapViewer> compoundPainter = new CompoundPainter<>(painters);
        jXMapViewer.setOverlayPainter(compoundPainter);
        
        for (MyWaypoint wp : waypoints) {
            jXMapViewer.add(wp.getButton());
        }
        
        jXMapViewer.revalidate();
        jXMapViewer.repaint();
    }

    // ===================== CLEAR WAYPOINTS =====================
    private void clearWaypoints() {
        for (MyWaypoint wp : waypoints) {
            jXMapViewer.remove(wp.getButton());
        }
        waypoints.clear();
        routeCoordinates.clear();
    }

    // ===================== EVENT HANDLER =====================
    private EventWaypoint getEvent() {
        return new EventWaypoint() {
            @Override
            public void selected(MyWaypoint waypoint) {
                // Check if it's a driver waypoint
                if (waypoint.getName().contains("(Driver)") && currentDriverId != -1) {
                    showDriverOptions(waypoint);
                } else {
                    JOptionPane.showMessageDialog(
                        TrackTransport.this, 
                        waypoint.getName()
                    );
                }
            }
        };
    }
    
    // ===================== SHOW DRIVER OPTIONS =====================
    private void showDriverOptions(MyWaypoint waypoint) {
        String[] options = {"View Info", "Send SMS", "Cancel"};
        int choice = JOptionPane.showOptionDialog(
            this,
            "Driver: " + currentDriverName + "\nWhat would you like to do?",
            "Driver Options",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]
        );
        
        if (choice == 0) {
            // View Info
            showDriverInfo();
        } else if (choice == 1) {
            // Send SMS
            showSMSDialog();
        }
    }
    
    // ===================== SHOW DRIVER INFO =====================
    private void showDriverInfo() {
        String info = "Driver Information:\n\n"
                + "Name: " + currentDriverName + "\n"
                + "Phone: " + currentDriverPhone + "\n"
                + "Driver ID: " + currentDriverId + "\n\n"
                + lblETA.getText();
        
        JOptionPane.showMessageDialog(this, info, "Driver Info", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // ===================== SHOW SMS DIALOG =====================
    private void showSMSDialog() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        JLabel label = new JLabel("Message to " + currentDriverName + ":");
        JTextArea messageArea = new JTextArea(5, 30);
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(messageArea);
        
        // Add pre-defined message templates
        String[] templates = {
            "Custom message...",
            "Where are you currently?",
            "Please update your location.",
            "Are you on your way?",
            "What time will you arrive?"
        };
        JComboBox<String> templateCombo = new JComboBox<>(templates);
        templateCombo.addActionListener(e -> {
            if (templateCombo.getSelectedIndex() > 0) {
                messageArea.setText((String) templateCombo.getSelectedItem());
            }
        });
        
        panel.add(label, BorderLayout.NORTH);
        panel.add(templateCombo, BorderLayout.CENTER);
        panel.add(scrollPane, BorderLayout.SOUTH);
        
        int result = JOptionPane.showConfirmDialog(
            this, 
            panel, 
            "Send SMS", 
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );
        
        if (result == JOptionPane.OK_OPTION) {
            String message = messageArea.getText().trim();
            if (!message.isEmpty() && !message.equals("Custom message...")) {
                sendSMS(currentDriverPhone, message);
            } else {
                JOptionPane.showMessageDialog(this, "Please enter a message.");
            }
        }
    }
    
    // ===================== SEND SMS =====================
    private void sendSMS(String phoneNumber, String message) {
        SwingWorker<BulkSmsClient.SMSResponse, Void> worker = new SwingWorker<BulkSmsClient.SMSResponse, Void>() {
            @Override
            protected BulkSmsClient.SMSResponse doInBackground() throws Exception {
                return BulkSmsClient.sendSMS(phoneNumber, message);
            }
            
            @Override
            protected void done() {
                try {
                    BulkSmsClient.SMSResponse response = get();
                    
                    if (response.isSuccess()) {
                        JOptionPane.showMessageDialog(
                            TrackTransport.this,
                            "SMS sent successfully to " + currentDriverName + "!\n" +
                            "Phone: " + phoneNumber,
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE
                        );
                    } else {
                        JOptionPane.showMessageDialog(
                            TrackTransport.this,
                            "Failed to send SMS.\n" + response.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                        );
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(
                        TrackTransport.this,
                        "Error sending SMS: " + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                    );
                }
            }
        };
        worker.execute();
    }

    // ===================== LOAD DRIVERS =====================
    private void loadDrivers() {
        try (Connection conn = DatabaseHelper.getConnection(); 
             PreparedStatement pst = conn.prepareStatement(
                 "SELECT driver_id, name FROM driver_registrations")) {

            ResultSet rs = pst.executeQuery();
            driverCombo.removeAllItems();
            driverCombo.addItem("-- Select Driver --");
            
            while (rs.next()) {
                int id = rs.getInt("driver_id");
                String name = rs.getString("name");
                driverCombo.addItem(id + " - " + name);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading drivers: " + ex.getMessage());
        }
    }

    // ===================== TRACK SELECTED DRIVER =====================
    private void trackSelectedDriver() {
        String selected = (String) driverCombo.getSelectedItem();
        
        if (selected == null || selected.equals("-- Select Driver --")) {
            addParentWaypoint();
            jXMapViewer.setAddressLocation(new GeoPosition(PARENT_LAT, PARENT_LON));
            jXMapViewer.setZoom(7);
            lblETA.setText("ETA: --");
            currentDriverId = -1;
            currentDriverName = "";
            currentDriverPhone = "";
            return;
        }

        currentDriverId = Integer.parseInt(selected.split(" - ")[0]);
        currentDriverName = selected.split(" - ")[1];

        // Fetch driver position and phone
        DriverPosition driverPos = fetchDriverPosition(currentDriverId);
        if (driverPos == null) {
            JOptionPane.showMessageDialog(this, 
                "No location found for " + currentDriverName);
            lblETA.setText("ETA: --");
            return;
        }
        
        currentDriverPhone = driverPos.phone;

        // Fetch realistic route from OpenRouteService or OSRM
        fetchRoute(PARENT_LAT, PARENT_LON, driverPos.latitude, driverPos.longitude);

        // Clear and add both waypoints
        clearWaypoints();
        
        MyWaypoint parentWaypoint = new MyWaypoint(
            "Parent Location (Kimberley)", 
            event, 
            new GeoPosition(PARENT_LAT, PARENT_LON)
        );
        waypoints.add(parentWaypoint);
        
        MyWaypoint driverWaypoint = new MyWaypoint(
            currentDriverName + " (Driver)", 
            event, 
            new GeoPosition(driverPos.latitude, driverPos.longitude)
        );
        waypoints.add(driverWaypoint);
        
        updateWaypoints();

        // Center map
        double centerLat = (PARENT_LAT + driverPos.latitude) / 2;
        double centerLon = (PARENT_LON + driverPos.longitude) / 2;
        jXMapViewer.setAddressLocation(new GeoPosition(centerLat, centerLon));
        jXMapViewer.setZoom(10);
    }
    
    // ===================== FETCH ROUTE FROM OSRM =====================
    private void fetchRoute(double startLat, double startLon, double endLat, double endLon) {
        SwingWorker<List<GeoPosition>, Void> worker = new SwingWorker<List<GeoPosition>, Void>() {
            @Override
            protected List<GeoPosition> doInBackground() throws Exception {
                List<GeoPosition> route = new ArrayList<>();
                
                try {
                    // Using OSRM (Open Source Routing Machine) - free and no API key needed
                    String urlString = String.format(
                        "http://router.project-osrm.org/route/v1/driving/%f,%f;%f,%f?overview=full&geometries=geojson",
                        startLon, startLat, endLon, endLat
                    );
                    
                    URL url = new URL(urlString);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    
                    BufferedReader reader = new BufferedReader(
                        new InputStreamReader(conn.getInputStream())
                    );
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    
                    // Parse JSON response
                    JSONObject json = new JSONObject(response.toString());
                    if (json.has("routes") && json.getJSONArray("routes").length() > 0) {
                        JSONObject routeObj = json.getJSONArray("routes").getJSONObject(0);
                        JSONObject geometry = routeObj.getJSONObject("geometry");
                        JSONArray coordinates = geometry.getJSONArray("coordinates");
                        
                        // Get route distance and duration
                        double distanceMeters = routeObj.getDouble("distance");
                        double durationSeconds = routeObj.getDouble("duration");
                        
                        // Update ETA with actual route data
                        double distanceKm = distanceMeters / 1000.0;
                        int minutes = (int) Math.round(durationSeconds / 60.0);
                        
                        SwingUtilities.invokeLater(() -> {
                            lblETA.setText("ETA: " + minutes + " min (~" + 
                                String.format("%.1f", distanceKm) + " km)");
                        });
                        
                        // Convert coordinates to GeoPosition
                        for (int i = 0; i < coordinates.length(); i++) {
                            JSONArray coord = coordinates.getJSONArray(i);
                            double lon = coord.getDouble(0);
                            double lat = coord.getDouble(1);
                            route.add(new GeoPosition(lat, lon));
                        }
                    }
                    
                } catch (Exception ex) {
                    ex.printStackTrace();
                    // Fallback to straight line if routing fails
                    route.add(new GeoPosition(startLat, startLon));
                    route.add(new GeoPosition(endLat, endLon));
                    
                    // Calculate straight-line distance as fallback
                    double distanceKm = haversineKm(startLat, startLon, endLat, endLon);
                    double avgSpeedKmh = 30.0;
                    int minutes = (int) Math.round((distanceKm / avgSpeedKmh) * 60.0);
                    
                    final int mins = minutes;
                    final double dist = distanceKm;
                    SwingUtilities.invokeLater(() -> {
                        lblETA.setText("ETA: " + mins + " min (~" + 
                            String.format("%.1f", dist) + " km) [Estimate]");
                    });
                }
                
                return route;
            }
            
            @Override
            protected void done() {
                try {
                    routeCoordinates = get();
                    updateWaypoints();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    // ===================== FETCH DRIVER POSITION =====================
    private DriverPosition fetchDriverPosition(int driverId) {
        String sql = "SELECT dr.Phone_number, dl.latitude, dl.longitude " +
                     "FROM driver_registrations dr " +
                     "LEFT JOIN driver_location dl ON dr.Driver_ID = dl.driver_id " +
                     "WHERE dr.Driver_ID = ?";
        try (Connection conn = DatabaseHelper.getConnection(); 
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            pst.setInt(1, driverId);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                double lat = rs.getDouble("latitude");
                double lon = rs.getDouble("longitude");
                String phone = rs.getString("Phone_number");
                
                // Check if location data exists
                if (rs.wasNull() || lat == 0.0 || lon == 0.0) {
                    JOptionPane.showMessageDialog(this,
                        "Driver location not available yet.\nDriver may not have GPS tracking enabled.",
                        "No Location Data",
                        JOptionPane.WARNING_MESSAGE
                    );
                    return null;
                }
                
                return new DriverPosition(lat, lon, phone);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "Database error: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
        return null;
    }

    // ===================== HELPER CLASS =====================
    private static class DriverPosition {
        double latitude;
        double longitude;
        String phone;

        DriverPosition(double lat, double lon, String phone) {
            this.latitude = lat;
            this.longitude = lon;
            this.phone = phone;
        }
    }

    // ===================== HAVERSINE FORMULA =====================
    private static double haversineKm(double lat1, double lon1, double lat2, double lon2) {
        double R = 6371.0;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    // ===================== CHANGE MAP TYPE =====================
    private void changeMapType(int index) {
        TileFactoryInfo info;
        
        switch (index) {
            case 0:
                info = new OSMTileFactoryInfo();
                break;
            case 1:
                info = new VirtualEarthTileFactoryInfo(VirtualEarthTileFactoryInfo.MAP);
                break;
            case 2:
                info = new VirtualEarthTileFactoryInfo(VirtualEarthTileFactoryInfo.HYBRID);
                break;
            case 3:
                info = new VirtualEarthTileFactoryInfo(VirtualEarthTileFactoryInfo.SATELLITE);
                break;
            default:
                info = new OSMTileFactoryInfo();
        }
        
        DefaultTileFactory tileFactory = new DefaultTileFactory(info);
        jXMapViewer.setTileFactory(tileFactory);
    }
    
    // ===================== ROUTE LINE PAINTER =====================
    private class RoutePainter implements Painter<JXMapViewer> {
        
        @Override
        public void paint(Graphics2D g, JXMapViewer map, int width, int height) {
            if (routeCoordinates.isEmpty()) {
                return;
            }
            
            Graphics2D g2d = (Graphics2D) g.create();
            
            // Enable antialiasing for smoother lines
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                                 RenderingHints.VALUE_ANTIALIAS_ON);
            
            Rectangle rect = map.getViewportBounds();
            
            // Draw the route as connected line segments
            g2d.setColor(new Color(0, 120, 255, 200));  // Blue route line
            g2d.setStroke(new BasicStroke(4, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            
            Point2D prevPoint = null;
            for (GeoPosition pos : routeCoordinates) {
                Point2D point = map.getTileFactory().geoToPixel(pos, map.getZoom());
                int x = (int)(point.getX() - rect.getX());
                int y = (int)(point.getY() - rect.getY());
                
                if (prevPoint != null) {
                    int prevX = (int)(prevPoint.getX() - rect.getX());
                    int prevY = (int)(prevPoint.getY() - rect.getY());
                    g2d.draw(new Line2D.Double(prevX, prevY, x, y));
                }
                
                prevPoint = point;
            }
            
            g2d.dispose();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        lblETA = new javax.swing.JLabel();
        driverCombo = new javax.swing.JComboBox<>();
        mapPanel = new javax.swing.JPanel();
        btnRefresh = new javax.swing.JButton();
        comboMapType = new javax.swing.JComboBox<>();

        jButton1.setText("jButton1");

        setBackground(new java.awt.Color(255, 255, 255));

        lblETA.setText("ETA:");

        driverCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                driverComboActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout mapPanelLayout = new javax.swing.GroupLayout(mapPanel);
        mapPanel.setLayout(mapPanelLayout);
        mapPanelLayout.setHorizontalGroup(
            mapPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 795, Short.MAX_VALUE)
        );
        mapPanelLayout.setVerticalGroup(
            mapPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 330, Short.MAX_VALUE)
        );

        btnRefresh.setBackground(new java.awt.Color(0, 153, 0));
        btnRefresh.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnRefresh.setForeground(new java.awt.Color(255, 255, 255));
        btnRefresh.setText("Refresh");

        comboMapType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Open Stree", "Virtual Earth", "Hybrid", "Satellite" }));
        comboMapType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboMapTypeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(mapPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(driverCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(comboMapType, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(lblETA, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnRefresh)))
                        .addGap(14, 14, 14))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(driverCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboMapType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblETA)
                    .addComponent(btnRefresh))
                .addGap(18, 18, 18)
                .addComponent(mapPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(12, 12, 12))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void driverComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_driverComboActionPerformed
        trackSelectedDriver();
    }//GEN-LAST:event_driverComboActionPerformed

    private void comboMapTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboMapTypeActionPerformed
        changeMapType(comboMapType.getSelectedIndex());
    }//GEN-LAST:event_comboMapTypeActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRefresh;
    private javax.swing.JComboBox<String> comboMapType;
    private javax.swing.JComboBox<String> driverCombo;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel lblETA;
    private javax.swing.JPanel mapPanel;
    // End of variables declaration//GEN-END:variables
}
