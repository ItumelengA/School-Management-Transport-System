
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Qr_codes extends javax.swing.JPanel {

    private BufferedImage generatedQR;
    private String currentLearnerName;

    public Qr_codes() {
        initComponents();
        loadLearners();
        createSavedQRCodesFolder();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        cmbLearners = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        btnGenerate = new javax.swing.JButton();
        btnSend = new javax.swing.JButton();
        QRPanel = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cmbLearners.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cmbLearnersItemStateChanged(evt);
            }
        });
        jPanel1.add(cmbLearners, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 70, 196, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        jLabel1.setText("Select Learner:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 70, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        jLabel2.setText("Email:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 100, 40, 30));

        txtEmail.setEditable(false);
        jPanel1.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 100, 196, -1));

        btnGenerate.setBackground(new java.awt.Color(0, 153, 0));
        btnGenerate.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnGenerate.setForeground(new java.awt.Color(255, 255, 255));
        btnGenerate.setText("Generate QR");
        btnGenerate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerateActionPerformed(evt);
            }
        });
        jPanel1.add(btnGenerate, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 150, 145, -1));

        btnSend.setBackground(new java.awt.Color(0, 102, 204));
        btnSend.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnSend.setForeground(new java.awt.Color(255, 255, 255));
        btnSend.setText("Send");
        btnSend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSendActionPerformed(evt);
            }
        });
        jPanel1.add(btnSend, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 150, 80, -1));

        QRPanel.setBackground(new java.awt.Color(255, 255, 255));
        QRPanel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        QRPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        javax.swing.GroupLayout QRPanelLayout = new javax.swing.GroupLayout(QRPanel);
        QRPanel.setLayout(QRPanelLayout);
        QRPanelLayout.setHorizontalGroup(
            QRPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 336, Short.MAX_VALUE)
        );
        QRPanelLayout.setVerticalGroup(
            QRPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 288, Short.MAX_VALUE)
        );

        jPanel1.add(QRPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 200, -1, -1));

        jLabel3.setFont(new java.awt.Font("Arial Black", 2, 14)); // NOI18N
        jLabel3.setText("Generate Qr codes");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 30, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1267, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 697, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents
private void loadLearners() {
        try (Connection conn = DatabaseHelper.getConnection()) {
            String sql = "SELECT Learner_ID, Name, MidName, Surname FROM learner";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            cmbLearners.removeAllItems();
            cmbLearners.addItem("-- Select Learner --");
            while (rs.next()) {
                int id = rs.getInt("Learner_ID");
                String fullName = rs.getString("Name") + " "
                        + rs.getString("MidName") + " "
                        + rs.getString("Surname");
                cmbLearners.addItem(id + " - " + fullName);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading learners: " + e.getMessage());
        }
    }

    private void createSavedQRCodesFolder() {
        File folder = new File("SavedQRCodes");
        if (!folder.exists()) {
            folder.mkdir();
        }
    }
    private void cmbLearnersItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cmbLearnersItemStateChanged
        if (evt.getStateChange() == java.awt.event.ItemEvent.SELECTED) {
            String selected = (String) cmbLearners.getSelectedItem();
            if (selected != null && !selected.equals("-- Select Learner --")) {
                String learnerId = selected.split(" - ")[0];
                try (java.sql.Connection conn = DatabaseHelper.getConnection()) {
                    // Join Learner -> Parent -> Login to get the email
                    String sql = "SELECT l.Name, l.MidName, l.Surname, log.Email "
                            + "FROM Learner l "
                            + "JOIN Parent p ON l.Parent_ID = p.Parent_ID "
                            + "JOIN Login log ON p.Login_ID = log.Login_ID "
                            + "WHERE l.Learner_ID = ?";

                    PreparedStatement pst = conn.prepareStatement(sql);
                    pst.setString(1, learnerId);
                    ResultSet rs = pst.executeQuery();

                    if (rs.next()) {
                        txtEmail.setText(rs.getString("Email")); // Get email from Login table
                        currentLearnerName = rs.getString("Name") + "_"
                                + rs.getString("MidName") + "_"
                                + rs.getString("Surname");
                    }

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
                }
            } else {
                txtEmail.setText("");
                currentLearnerName = "";
                QRPanel.removeAll();
                QRPanel.revalidate();
                QRPanel.repaint();
            }
        }
    }//GEN-LAST:event_cmbLearnersItemStateChanged

    private void btnGenerateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerateActionPerformed
        String selected = (String) cmbLearners.getSelectedItem();
        if (selected == null || selected.equals("-- Select Learner --")) {
            JOptionPane.showMessageDialog(this, "Please select a learner");
            return;
        }

        String learnerId = selected.split(" - ")[0];
        String qrData = "SMTS-" + learnerId;

        try {
            // Generate QR Code in memory
            QRCodeWriter qrWriter = new QRCodeWriter();
            BitMatrix matrix = qrWriter.encode(qrData, BarcodeFormat.QR_CODE, 300, 300);

            generatedQR = new BufferedImage(300, 300, BufferedImage.TYPE_INT_RGB);
            for (int x = 0; x < 300; x++) {
                for (int y = 0; y < 300; y++) {
                    generatedQR.setRGB(x, y, matrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
                }
            }

            // Display in panel
            displayQRCode(generatedQR);

            JOptionPane.showMessageDialog(this, "QR Code generated.");
            btnSend.setEnabled(true);

        } catch (WriterException e) {
            JOptionPane.showMessageDialog(this, "Error generating QR code: " + e.getMessage());
        }
    }//GEN-LAST:event_btnGenerateActionPerformed

    private void btnSendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSendActionPerformed
        String selected = (String) cmbLearners.getSelectedItem();
        if (selected == null || selected.equals("-- Select Learner --")) {
            JOptionPane.showMessageDialog(this, "Please select a learner");
            return;
        }

        if (generatedQR == null) {
            JOptionPane.showMessageDialog(this, "Please generate the QR code first");
            return;
        }

        String learnerId = selected.split(" - ")[0];
        String email = txtEmail.getText();

        try {
            // Save QR code to file
            String fileName = "SavedQRCodes/" + currentLearnerName + ".png";
            File outputFile = new File(fileName);
            ImageIO.write(generatedQR, "png", outputFile);

            // Open Gmail with pre-filled details
            String subject = "Your QR Code";
            String body = "Dear " + currentLearnerName.replace("_", " ") + ",\n\n"
                    + "Please find attached your QR code for school access.\n\n"
                    + "Best regards,\nSchool Management Team";

            String uri = "https://mail.google.com/mail/?view=cm"
                    + "&to=" + URLEncoder.encode(email, "UTF-8")
                    + "&su=" + URLEncoder.encode(subject, "UTF-8")
                    + "&body=" + URLEncoder.encode(body, "UTF-8")
                    + "&attach=" + URLEncoder.encode(outputFile.getAbsolutePath(), "UTF-8");

            Desktop.getDesktop().browse(new URI(uri));

            JOptionPane.showMessageDialog(this, "QR code saved and email draft opened in browser");

        } catch (IOException | URISyntaxException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_btnSendActionPerformed

    private void displayQRCode(BufferedImage image) {
        QRPanel.removeAll();
        Image scaledImage = image.getScaledInstance(QRPanel.getWidth(), QRPanel.getHeight(), Image.SCALE_SMOOTH);
        JLabel qrLabel = new JLabel(new ImageIcon(scaledImage));
        QRPanel.setLayout(new BorderLayout());
        QRPanel.add(qrLabel, BorderLayout.CENTER);
        QRPanel.revalidate();
        QRPanel.repaint();

    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel QRPanel;
    private javax.swing.JButton btnGenerate;
    private javax.swing.JButton btnSend;
    private javax.swing.JComboBox<String> cmbLearners;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtEmail;
    // End of variables declaration//GEN-END:variables
}
