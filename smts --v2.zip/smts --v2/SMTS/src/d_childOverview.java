
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Time;
import java.text.SimpleDateFormat;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class d_childOverview extends javax.swing.JPanel {

    private Driver loggedInDriver;

    public d_childOverview(Driver driver) {
        this.loggedInDriver = driver;
        initComponents();

        String driverName = txtChildName.getText().trim();
        loadData(driverName, loggedInDriver);
    }

    public void setLoggedInDriver(Driver driver) {
        this.loggedInDriver = driver;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtChildName = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanelCards = new javax.swing.JPanel();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtChildName.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        txtChildName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtChildNameActionPerformed(evt);
            }
        });
        jPanel1.add(txtChildName, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, 290, 31));

        btnSearch.setBackground(new java.awt.Color(102, 102, 255));
        btnSearch.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });
        jPanel1.add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 70, -1, 31));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jPanelCards.setLayout(new javax.swing.BoxLayout(jPanelCards, javax.swing.BoxLayout.LINE_AXIS));
        jScrollPane1.setViewportView(jPanelCards);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(99, 99, 99)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 669, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(104, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(126, 126, 126)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 947, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 524, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtChildNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtChildNameActionPerformed

    }//GEN-LAST:event_txtChildNameActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        String searchText = txtChildName.getText();
        loadData(searchText, loggedInDriver);
    }//GEN-LAST:event_btnSearchActionPerformed

    private void loadData(String childName, Driver driver) {
        if (driver == null) {
            JOptionPane.showMessageDialog(this, "No driver is logged in");
            return;
        }

        System.out.println("Loading data for Driver ID: " + driver.getDriverId());
        System.out.println("Driver Login ID: " + driver.getLoginId());
        System.out.println("Driver Name: " + driver.getFirstName() + " " + driver.getSurname());

        try (Connection con = DatabaseHelper.getConnection()) {

            StringBuilder sql = new StringBuilder(
                    "SELECT Arrangement_ID, Driver_Name, Driver_Surname, "
                    + "Pickup_Location, Dropoff_Location, Time_Morning, Time_Afternoon, "
                    + "Learner_Name, Learner_Surname "
                    + "FROM Arrangement WHERE Driver_ID = ?"
            );

            boolean hasChild = childName != null && !childName.trim().isEmpty();
            if (hasChild) {
                sql.append(" AND (Learner_Name LIKE ? OR Learner_Surname LIKE ?)");
            }

            PreparedStatement stmt = con.prepareStatement(sql.toString());
            stmt.setInt(1, driver.getDriverId());

            if (hasChild) {
                stmt.setString(2, "%" + childName.trim() + "%");
                stmt.setString(3, "%" + childName.trim() + "%");
            }

            ResultSet rs = stmt.executeQuery();

            // ---------- build cards ----------
            jPanelCards.removeAll();
            jPanelCards.setLayout(new BoxLayout(jPanelCards, BoxLayout.Y_AXIS));
            jPanelCards.setBackground(new Color(240, 240, 240));
            jPanelCards.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");

            while (rs.next()) {
                JPanel card = new JPanel(new BorderLayout(15, 15));
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                        BorderFactory.createEmptyBorder(20, 20, 20, 20)
                ));
                card.setBackground(Color.WHITE);
                card.setMaximumSize(new Dimension(650, 180));
                card.setPreferredSize(new Dimension(650, 180));

                JPanel contentPanel = new JPanel();
                contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
                contentPanel.setOpaque(false);

                int arrangementId = rs.getInt("Arrangement_ID");
                String driverFullName = rs.getString("Driver_Name") + " " + rs.getString("Driver_Surname");
                String learnerFullName = rs.getString("Learner_Name") + " " + rs.getString("Learner_Surname");
                String pickup = rs.getString("Pickup_Location");
                String dropoff = rs.getString("Dropoff_Location");
                Time morningTime = rs.getTime("Time_Morning");
                Time afternoonTime = rs.getTime("Time_Afternoon");

                String timeText1 = (morningTime != null) ? "Morning pickup: " + timeFormat.format(morningTime) : "";
                String timeText2 = (afternoonTime != null) ? "Afternoon pickup: " + timeFormat.format(afternoonTime) : "";

                JLabel lblBooking = new JLabel("Arrangement #" + arrangementId);
                lblBooking.setFont(new Font("Segoe UI", Font.BOLD, 13));
                lblBooking.setForeground(new Color(128, 0, 128));

                JLabel lblDriver = new JLabel("Driver: " + driverFullName);
                lblDriver.setFont(new Font("Segoe UI", Font.BOLD, 14));
                lblDriver.setForeground(new Color(70, 130, 180));

                JLabel lblLearner = new JLabel("Learner: " + learnerFullName);
                lblLearner.setFont(new Font("Segoe UI", Font.BOLD, 14));
                lblLearner.setForeground(new Color(34, 139, 34));

                JLabel lblPickup = new JLabel("Pickup: " + pickup);
                JLabel lblDropoff = new JLabel("Dropoff: " + dropoff);
                JLabel lblTime = new JLabel(timeText1);
                JLabel lblAfternoon = new JLabel(timeText2);

                contentPanel.add(lblBooking);
                contentPanel.add(lblDriver);
                contentPanel.add(lblLearner);
                contentPanel.add(lblPickup);
                contentPanel.add(lblDropoff);
                contentPanel.add(lblTime);
                contentPanel.add(lblAfternoon);

                card.add(contentPanel, BorderLayout.CENTER);
                card.add(new JPanel(), BorderLayout.EAST);

                jPanelCards.add(card);
                jPanelCards.add(Box.createRigidArea(new Dimension(0, 15)));
            }

            jScrollPane1.setViewportView(jPanelCards);
            jPanelCards.revalidate();
            jPanelCards.repaint();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanelCards;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtChildName;
    // End of variables declaration//GEN-END:variables
}
