
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class BulkSmsClient {

    private static final String BULK_SMS_URL = "https://api.bulksms.com/v1/messages";
    private static final String USERNAME = "boago";
    private static final String PASSWORD = "Spu@2004";

    public static SMSResponse sendSMS(String to, String message) {
        try {
            // Validate input
            if (to == null || to.trim().isEmpty()) {
                return new SMSResponse(false, "Phone number is required");
            }
            if (message == null || message.trim().isEmpty()) {
                return new SMSResponse(false, "Message is required");
            }

            // Format phone number if needed
            String formattedPhone = formatPhoneNumber(to);

            // Build JSON payload
            String jsonPayload = buildJsonPayload(formattedPhone, message);

            // Make HTTP request
            URL url = new URL(BULK_SMS_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");

            // Add Basic Authentication
            String auth = USERNAME + ":" + PASSWORD;
            String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
            conn.setRequestProperty("Authorization", "Basic " + encodedAuth);
            conn.setRequestProperty("Content-Type", "application/json");

            // Send request
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            // Get response
            int responseCode = conn.getResponseCode();

            if (responseCode == 200 || responseCode == 201) {
                // Success
                String responseBody = readResponse(conn.getInputStream());
                return new SMSResponse(true, "SMS sent successfully", responseBody);
            } else {
                // Error
                String errorBody = readResponse(conn.getErrorStream());
                return new SMSResponse(false, "Failed to send SMS. HTTP " + responseCode, errorBody);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return new SMSResponse(false, "Exception: " + e.getMessage());
        }
    }

    /**
     * Build JSON payload for BulkSMS API
     */
    private static String buildJsonPayload(String to, String message) {
        // Escape special characters in message
        String escapedMessage = message
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");

        return String.format("{\"to\":\"%s\",\"body\":\"%s\"}", to, escapedMessage);
    }

    /**
     * Format phone number to ensure it has country code
     */
    private static String formatPhoneNumber(String phone) {
        // Remove spaces, dashes, and parentheses
        String cleaned = phone.replaceAll("[\\s\\-()]", "");

        // If starts with 0, replace with +27 (South Africa)
        if (cleaned.startsWith("0")) {
            cleaned = "+27" + cleaned.substring(1);
        }

        // If doesn't start with +, add +27
        if (!cleaned.startsWith("+")) {
            cleaned = "+27" + cleaned;
        }

        return cleaned;
    }

    /**
     * Read response from input stream
     */
    private static String readResponse(InputStream inputStream) throws IOException {
        if (inputStream == null) {
            return "";
        }

        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder response = new StringBuilder();
        String line;

        while ((line = reader.readLine()) != null) {
            response.append(line);
        }

        reader.close();
        return response.toString();
    }

    /**
     * Send SMS to multiple recipients
     *
     * @param recipients Array of phone numbers
     * @param message SMS message content
     * @return Array of SMSResponse objects
     */
    public static SMSResponse[] sendBulkSMS(String[] recipients, String message) {
        SMSResponse[] responses = new SMSResponse[recipients.length];

        for (int i = 0; i < recipients.length; i++) {
            responses[i] = sendSMS(recipients[i], message);

            // Small delay between messages to avoid rate limiting
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        return responses;
    }

    /**
     * Response class for SMS operations
     */
    public static class SMSResponse {

        private boolean success;
        private String message;
        private String responseBody;

        public SMSResponse(boolean success, String message) {
            this.success = success;
            this.message = message;
            this.responseBody = "";
        }

        public SMSResponse(boolean success, String message, String responseBody) {
            this.success = success;
            this.message = message;
            this.responseBody = responseBody;
        }

        public boolean isSuccess() {
            return success;
        }

        public String getMessage() {
            return message;
        }

        public String getResponseBody() {
            return responseBody;
        }

        @Override
        public String toString() {
            return "SMSResponse{success=" + success
                    + ", message='" + message + "'"
                    + ", responseBody='" + responseBody + "'}";
        }
    }

    /**
     * Test method - for development/testing only
     */
    public static void main(String[] args) {
        // Test sending SMS
        String testPhone = "+27796408096";
        String testMessage = "Test message from Transport System";

        System.out.println("Sending test SMS to: " + testPhone);
        SMSResponse response = sendSMS(testPhone, testMessage);

        System.out.println("Result: " + response.toString());
    }
}
