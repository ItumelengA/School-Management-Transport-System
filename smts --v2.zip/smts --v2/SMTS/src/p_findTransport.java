
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.sql.Time;
import javax.swing.Box;
import java.sql.SQLException;

public class p_findTransport extends javax.swing.JPanel {

    private Parent loggedInParent;

    public p_findTransport() {
        initComponents();
        loadData(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtSearchbar = new javax.swing.JTextField();
        scrollpane = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        btnsearch = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtSearchbar1 = new javax.swing.JTextField();
        scrollpane1 = new javax.swing.JScrollPane();
        jPanel3 = new javax.swing.JPanel();
        btnsearch1 = new javax.swing.JButton();

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jPanel6.setBackground(new java.awt.Color(204, 255, 204));

        jLabel1.setBackground(new java.awt.Color(204, 204, 204));
        jLabel1.setFont(new java.awt.Font("SimSun", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        jLabel1.setText("Parent");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(47, 47, 47))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18))
        );

        scrollpane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollpane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 680, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 366, Short.MAX_VALUE)
        );

        scrollpane.setViewportView(jPanel2);

        btnsearch.setBackground(new java.awt.Color(0, 102, 204));
        btnsearch.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnsearch.setForeground(new java.awt.Color(255, 255, 255));
        btnsearch.setText("Search");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(117, 117, 117)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtSearchbar, javax.swing.GroupLayout.PREFERRED_SIZE, 382, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(380, 380, 380)
                        .addComponent(btnsearch))
                    .addComponent(scrollpane, javax.swing.GroupLayout.PREFERRED_SIZE, 680, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(173, Short.MAX_VALUE))
            .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtSearchbar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnsearch))
                .addGap(7, 7, 7)
                .addComponent(scrollpane, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 64, Short.MAX_VALUE))
        );

        setMinimumSize(new java.awt.Dimension(1047, 539));
        setName(""); // NOI18N
        setPreferredSize(new java.awt.Dimension(1047, 539));

        jPanel1.setBackground(new java.awt.Color(249, 249, 249));
        jPanel1.setToolTipText("");
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel8.setBackground(new java.awt.Color(204, 255, 204));

        jLabel2.setBackground(new java.awt.Color(204, 204, 204));
        jLabel2.setFont(new java.awt.Font("SimSun", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 153, 153));
        jLabel2.setText("Parent");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(47, 47, 47))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18))
        );

        jPanel7.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, -1));

        txtSearchbar1.setToolTipText("");
        txtSearchbar1.setMinimumSize(new java.awt.Dimension(73, 22));
        jPanel7.add(txtSearchbar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(122, 80, 390, 30));

        scrollpane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollpane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 812, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 366, Short.MAX_VALUE)
        );

        scrollpane1.setViewportView(jPanel3);

        jPanel7.add(scrollpane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 130, 680, 360));

        btnsearch1.setBackground(new java.awt.Color(0, 102, 204));
        btnsearch1.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnsearch1.setForeground(new java.awt.Color(255, 255, 255));
        btnsearch1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/search_2.png"))); // NOI18N
        btnsearch1.setText("Search");
        btnsearch1.setPreferredSize(new java.awt.Dimension(72, 22));
        btnsearch1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearch1ActionPerformed(evt);
            }
        });
        jPanel7.add(btnsearch1, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 80, 110, 30));

        jPanel1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, 890, 510));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    public void setLoggedInParent(Parent parent) {
        this.loggedInParent = parent;
    }

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
        String searchText = txtSearchbar.getText();
        loadData(searchText);

    }//GEN-LAST:event_btnsearchActionPerformed

    private void btnsearch1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearch1ActionPerformed
        String searchText = txtSearchbar1.getText();
        loadData(searchText);
    }//GEN-LAST:event_btnsearch1ActionPerformed
    private void loadData(String schoolFilter) {
        try (Connection con = DatabaseHelper.getConnection()) {
            String query = "SELECT Driver_ID, Name, Surname, Phone_number, School_name, Time_morning, Time_afternoon, Charge_amount_R "
                    + "FROM driver_registrations";

            if (schoolFilter != null && !schoolFilter.trim().isEmpty()) {
                query += " WHERE School_name LIKE ?";
            }

            PreparedStatement stmt = con.prepareStatement(query);

            if (schoolFilter != null && !schoolFilter.trim().isEmpty()) {
                stmt.setString(1, "%" + schoolFilter.trim() + "%");
            }

            ResultSet rs = stmt.executeQuery();

            // Clear panel - Use the correct panel that's actually visible
            jPanel3.removeAll();
            jPanel3.setLayout(new BoxLayout(jPanel3, BoxLayout.Y_AXIS));
            jPanel3.setBackground(new Color(240, 240, 240));
            jPanel3.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            while (rs.next()) {
                // CAPTURE THE DRIVER ID BEFORE THE RESULTSET CLOSES
                final int driverId = rs.getInt("Driver_ID"); // Make it final for use in lambda

                // Main card panel
                JPanel card = new JPanel();
                card.setLayout(new BorderLayout(15, 15));
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                        BorderFactory.createEmptyBorder(20, 20, 20, 20)
                ));
                card.setBackground(Color.WHITE);
                card.setMaximumSize(new Dimension(650, 150));
                card.setPreferredSize(new Dimension(650, 150));

                // Left content panel
                JPanel contentPanel = new JPanel();
                contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
                contentPanel.setOpaque(false);

                // Get data from correct column names
                String fullName = rs.getString("Name") + " " + rs.getString("Surname");
                String school = rs.getString("School_name");
                String phone = rs.getString("Phone_number");

                // School label
                JLabel lblSchool = new JLabel("School: " + school);
                lblSchool.setFont(new Font("Segoe UI", Font.BOLD, 14));
                lblSchool.setForeground(new Color(70, 130, 180));

                // Driver label
                JLabel lblDriver = new JLabel("Driver: " + fullName);
                lblDriver.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                lblDriver.setForeground(new Color(51, 51, 51));

                // Handle both morning and afternoon times
                Time morningTime = rs.getTime("Time_morning");
                Time afternoonTime = rs.getTime("Time_afternoon");
                String timeText = "";
                if (morningTime != null) {
                    timeText += "Morning: " + morningTime.toString();
                }
                if (afternoonTime != null) {
                    if (morningTime != null) {
                        timeText += ", ";
                    }
                    timeText += "Afternoon: " + afternoonTime.toString();
                }

                // Time label
                JLabel lblTime = new JLabel("Times: " + timeText);
                lblTime.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                lblTime.setForeground(new Color(100, 100, 100));

                // Price label
                JLabel lblPrice = new JLabel("Price: R" + String.format("%.2f", rs.getDouble("Charge_amount_R")));
                lblPrice.setFont(new Font("Segoe UI", Font.BOLD, 12));
                lblPrice.setForeground(new Color(0, 100, 0));

                // Contact label
                JLabel lblContact = new JLabel("Contact: " + phone);
                lblContact.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                lblContact.setForeground(new Color(100, 100, 100));

                // Add components to content panel
                contentPanel.add(lblSchool);
                contentPanel.add(lblContact);
                contentPanel.add(lblDriver);
                contentPanel.add(lblPrice);
                contentPanel.add(lblTime);

                // Right panel for arrange button
                JPanel rightPanel = new JPanel();
                rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
                rightPanel.setOpaque(false);
                rightPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));

                // Arrange button
                JButton arrangeBtn = new JButton("Arrange");
                styleButton(arrangeBtn, new Color(0, 102, 204)); // Blue color
                arrangeBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
                arrangeBtn.setMaximumSize(new Dimension(120, 40));
                arrangeBtn.setPreferredSize(new Dimension(120, 40));

                arrangeBtn.addActionListener(e -> {
                    String message = "Arranging transport for " + school;

                    // NOW USE THE CAPTURED driverId (no more ResultSet access needed)
                    boolean success = arrangeTransport(driverId, loggedInParent.getParentId());
                    if (success) {
                        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to arrange transport.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                });

                rightPanel.add(Box.createVerticalGlue());
                rightPanel.add(arrangeBtn);
                rightPanel.add(Box.createVerticalGlue());

                // Add panels to card
                card.add(contentPanel, BorderLayout.CENTER);
                card.add(rightPanel, BorderLayout.EAST);

                // Add card to main panel with spacing
                jPanel3.add(card);
                jPanel3.add(Box.createRigidArea(new Dimension(0, 15))); // Add spacing between cards
            }

            // Add glue to push content to top
            jPanel3.add(Box.createVerticalGlue());

            jPanel3.revalidate();
            jPanel3.repaint();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Style button method
    private void styleButton(JButton button, Color bgColor) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
    }

    // This method will fetch data from driver_registrations and learner
    public boolean arrangeTransport(int driverId, int parentId) {
        String driverQuery = "SELECT Name, Surname, Time_morning, Time_afternoon, School_name FROM driver_registrations WHERE Driver_ID = ?";
        String parentQuery = "SELECT Name, Surname FROM parent WHERE Parent_ID = ?";
        String learnerQuery = "SELECT Learner_ID, Name, Surname, Pickup_Location, Dropoff_Location FROM learner WHERE Parent_ID = ?";

        try (Connection conn = DatabaseHelper.getConnection(); PreparedStatement driverStmt = conn.prepareStatement(driverQuery); PreparedStatement parentStmt = conn.prepareStatement(parentQuery); PreparedStatement learnerStmt = conn.prepareStatement(learnerQuery)) {

            // Get driver info
            driverStmt.setInt(1, driverId);
            ResultSet driverRs = driverStmt.executeQuery();

            // Get parent info
            parentStmt.setInt(1, parentId);
            ResultSet parentRs = parentStmt.executeQuery();

            // Get learner info for this parent
            learnerStmt.setInt(1, parentId);
            ResultSet learnerRs = learnerStmt.executeQuery();

            if (driverRs.next() && parentRs.next() && learnerRs.next()) {
                // Driver details
                String driverName = driverRs.getString("Name");
                String driverSurname = driverRs.getString("Surname");

                // Handle TIME columns properly - get as Time objects then convert to strings
                java.sql.Time timeMorningObj = driverRs.getTime("Time_morning");
                java.sql.Time timeAfternoonObj = driverRs.getTime("Time_afternoon");

                // Convert Time objects to strings in HH:mm:ss format (required by saveArrangement)
                String timeMorning = (timeMorningObj != null) ? timeMorningObj.toString() : null;
                String timeAfternoon = (timeAfternoonObj != null) ? timeAfternoonObj.toString() : null;

                String schoolName = driverRs.getString("School_name");

                // Parent details
                String parentName = parentRs.getString("Name");
                String parentSurname = parentRs.getString("Surname");

                // Learner details
                int learnerId = learnerRs.getInt("Learner_ID");
                String learnerName = learnerRs.getString("Name");
                String learnerSurname = learnerRs.getString("Surname");
                String pickup = learnerRs.getString("Pickup_Location");
                String dropoff = learnerRs.getString("Dropoff_Location");

                // Close ResultSets before calling saveArrangement to avoid any resource conflicts
                driverRs.close();
                parentRs.close();
                learnerRs.close();

                // Save into Arrangement with all necessary relationships
                return DatabaseHelper.saveArrangement(
                        driverId, driverName, driverSurname,
                        parentId, parentName, parentSurname,
                        learnerId, learnerName, learnerSurname,
                        pickup, dropoff,
                        timeMorning, timeAfternoon,
                        schoolName
                );

            } else {
                // More detailed error reporting
                if (!driverRs.next()) {
                    System.out.println("Driver with ID " + driverId + " not found.");
                }
                if (!parentRs.next()) {
                    System.out.println("Parent with ID " + parentId + " not found.");
                }
                if (!learnerRs.next()) {
                    System.out.println("No learner found for parent ID " + parentId);
                }
                return false;
            }

        } catch (SQLException e) {
            System.out.println("SQLException in arrangeTransport: " + e.getMessage());
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            System.out.println("General exception in arrangeTransport: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnsearch;
    private javax.swing.JButton btnsearch1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane scrollpane;
    private javax.swing.JScrollPane scrollpane1;
    private javax.swing.JTextField txtSearchbar;
    private javax.swing.JTextField txtSearchbar1;
    // End of variables declaration//GEN-END:variables
}
