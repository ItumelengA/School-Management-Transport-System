
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class ViewReviews extends javax.swing.JPanel {

    /**
     * Creates new form ViewReviews
     */
    public ViewReviews() {
        initComponents();
        loadReviews("", "");

    }

    private void loadReviews(String driverFilter, String yearFilter) {
        try (Connection con = DatabaseHelper.getConnection()) {

            // Build query safely with WHERE / AND logic
            StringBuilder query = new StringBuilder(
                    "SELECT Review_ID, Parent_Name, Driver_Name, Comment, Review_Date FROM Reviews"
            );

            boolean hasWhere = false;

            if (driverFilter != null && !driverFilter.isEmpty()) {
                query.append(" WHERE Driver_Name LIKE ?");
                hasWhere = true;
            }
            if (yearFilter != null && !yearFilter.isEmpty() && !yearFilter.equals("All")) {
                if (hasWhere) {
                    query.append(" AND YEAR(Review_Date) = ?");
                } else {
                    query.append(" WHERE YEAR(Review_Date) = ?");
                    hasWhere = true;
                }
            }

            query.append(" ORDER BY Review_Date DESC");

            PreparedStatement stmt = con.prepareStatement(query.toString());

            int index = 1;
            if (driverFilter != null && !driverFilter.isEmpty()) {
                stmt.setString(index++, "%" + driverFilter + "%");
            }
            if (yearFilter != null && !yearFilter.isEmpty() && !yearFilter.equals("All")) {
                stmt.setInt(index++, Integer.parseInt(yearFilter));
            }

            ResultSet rs = stmt.executeQuery();

            // Clear previous content
            jPanel1.removeAll();
            jPanel1.setLayout(new BoxLayout(jPanel1, BoxLayout.Y_AXIS));

            boolean hasReviews = false;

            while (rs.next()) {
                hasReviews = true;

                JPanel card = new JPanel(new BorderLayout(10, 10));
                card.setBackground(Color.WHITE);
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(200, 200, 200)),
                        BorderFactory.createEmptyBorder(10, 10, 10, 10)
                ));
                card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 140));

                // LEFT PANEL
                JPanel leftPanel = new JPanel(new GridLayout(4, 1, 5, 5));
                leftPanel.setOpaque(false);

                JLabel lblParent = new JLabel("Parent: " + rs.getString("Parent_Name"));
                lblParent.setFont(new Font("Segoe UI", Font.BOLD, 14));

                JLabel lblDriver = new JLabel("Driver: " + rs.getString("Driver_Name"));
                lblDriver.setFont(new Font("Segoe UI", Font.PLAIN, 12));

                Date reviewDate = rs.getDate("Review_Date");
                String formattedDate = (reviewDate != null) ? reviewDate.toString() : "Unknown";
                JLabel lblDate = new JLabel("Date: " + formattedDate);
                lblDate.setFont(new Font("Segoe UI", Font.ITALIC, 12));

                JLabel lblComment = new JLabel("<html>Comment: " + rs.getString("Comment") + "</html>");
                lblComment.setFont(new Font("Segoe UI", Font.PLAIN, 12));

                leftPanel.add(lblParent);
                leftPanel.add(lblDriver);
                leftPanel.add(lblDate);
                leftPanel.add(lblComment);

                // RIGHT PANEL (Delete Button)
                JPanel rightPanel = new JPanel();
                rightPanel.setOpaque(false);
                rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));

                JButton btnDelete = new JButton("Delete");
                styleButton(btnDelete, new Color(200, 0, 0));

                int reviewId = rs.getInt("Review_ID");
                btnDelete.addActionListener(e -> {
                    int confirm = JOptionPane.showConfirmDialog(this,
                            "Are you sure you want to delete this review?", "Confirm Delete",
                            JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        deleteReview(reviewId);
                        loadReviews(txtSearchBar.getText(), cmbFilterDate.getSelectedItem().toString());
                    }
                });

                rightPanel.add(btnDelete);
                rightPanel.add(Box.createVerticalGlue());

                // Assemble card
                card.add(leftPanel, BorderLayout.CENTER);
                card.add(rightPanel, BorderLayout.EAST);

                jPanel1.add(card);
                jPanel1.add(Box.createRigidArea(new Dimension(0, 10))); // Spacing between cards
            }

            if (!hasReviews) {
                JLabel noReviewsLabel = new JLabel("No reviews found", SwingConstants.CENTER);
                noReviewsLabel.setFont(new Font("Segoe UI", Font.ITALIC, 16));
                noReviewsLabel.setForeground(Color.GRAY);
                jPanel1.add(noReviewsLabel);
            }

            jPanel1.revalidate();
            jPanel1.repaint();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to load reviews. Please try again.");
            e.printStackTrace();
        }
    }

    private void deleteReview(int reviewId) {
        try (Connection con = DatabaseHelper.getConnection()) {
            PreparedStatement stmt = con.prepareStatement("DELETE FROM Reviews WHERE Review_ID = ?");
            stmt.setInt(1, reviewId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Review deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "No review found to delete.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error deleting review: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void styleButton(JButton button, Color bgColor) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cmbFilterDate = new javax.swing.JComboBox<>();
        txtSearchBar = new javax.swing.JTextField();
        btnSerach = new javax.swing.JButton();

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(810, 396));
        setPreferredSize(new java.awt.Dimension(810, 396));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 613, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 301, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(jPanel1);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 625, 303));

        jLabel1.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel1.setText("Filter:");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, 40, 30));

        cmbFilterDate.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        cmbFilterDate.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "2025", "2024", "2023", "2022", "2021" }));
        add(cmbFilterDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 100, 154, -1));

        txtSearchBar.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        add(txtSearchBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, 490, 30));

        btnSerach.setBackground(new java.awt.Color(0, 102, 204));
        btnSerach.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnSerach.setForeground(new java.awt.Color(255, 255, 255));
        btnSerach.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/search_2.png"))); // NOI18N
        btnSerach.setText("Search");
        btnSerach.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSerachActionPerformed(evt);
            }
        });
        add(btnSerach, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 60, 110, 30));
    }// </editor-fold>//GEN-END:initComponents

    private void btnSerachActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSerachActionPerformed
        String driverName = txtSearchBar.getText().trim();
        String selectedYear = cmbFilterDate.getSelectedItem().toString();

        loadReviews(driverName, selectedYear);
    }//GEN-LAST:event_btnSerachActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSerach;
    private javax.swing.JComboBox<String> cmbFilterDate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtSearchBar;
    // End of variables declaration//GEN-END:variables
}
