
import javax.swing.JOptionPane;

public class forgotPassword extends javax.swing.JFrame {

    private DatabaseHelper dbHelper;

    public forgotPassword() {
        initComponents();
        dbHelper = new DatabaseHelper();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        rbDocSpecialist = new javax.swing.JRadioButton();
        rbAdmin = new javax.swing.JRadioButton();
        rbDriver = new javax.swing.JRadioButton();
        rbParent = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        btnReset = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        txtRePassword = new javax.swing.JPasswordField();
        txtPassword = new javax.swing.JPasswordField();
        lblError = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setFocusCycleRoot(true);
        jPanel1.setInheritsPopupMenu(true);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("Forgot Password");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 30, -1, -1));

        jPanel2.setBackground(new java.awt.Color(153, 153, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, " Identification type", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Semibold", 1, 12))); // NOI18N
        jPanel2.setForeground(new java.awt.Color(51, 51, 51));

        rbDocSpecialist.setBackground(new java.awt.Color(153, 153, 255));
        buttonGroup1.add(rbDocSpecialist);
        rbDocSpecialist.setForeground(new java.awt.Color(255, 255, 255));
        rbDocSpecialist.setText("Document Specialist");

        rbAdmin.setBackground(new java.awt.Color(153, 153, 255));
        buttonGroup1.add(rbAdmin);
        rbAdmin.setForeground(new java.awt.Color(255, 255, 255));
        rbAdmin.setText("Admin");

        rbDriver.setBackground(new java.awt.Color(153, 153, 255));
        buttonGroup1.add(rbDriver);
        rbDriver.setForeground(new java.awt.Color(255, 255, 255));
        rbDriver.setText("Driver");

        rbParent.setBackground(new java.awt.Color(153, 153, 255));
        buttonGroup1.add(rbParent);
        rbParent.setForeground(new java.awt.Color(255, 255, 255));
        rbParent.setText("Parent");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(rbParent)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addComponent(rbDriver)
                .addGap(61, 61, 61)
                .addComponent(rbAdmin)
                .addGap(39, 39, 39)
                .addComponent(rbDocSpecialist)
                .addGap(47, 47, 47))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbDriver)
                    .addComponent(rbParent)
                    .addComponent(rbAdmin)
                    .addComponent(rbDocSpecialist))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 590, 57));

        jPanel3.setBackground(new java.awt.Color(242, 242, 242));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("Email");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 14, -1, -1));

        txtEmail.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jPanel3.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 40, 180, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setText("Re-enter password");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 142, -1, -1));

        btnReset.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnReset.setText("Reset");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });
        jPanel3.add(btnReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(79, 203, -1, -1));

        btnClear.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });
        jPanel3.add(btnClear, new org.netbeans.lib.awtextra.AbsoluteConstraints(158, 203, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(102, 102, 102));
        jLabel4.setText("Password");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 75, -1, -1));

        txtRePassword.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jPanel3.add(txtRePassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 168, 180, -1));

        txtPassword.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        txtPassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPasswordMouseClicked(evt);
            }
        });
        jPanel3.add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 107, 180, -1));

        lblError.setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        lblError.setForeground(new java.awt.Color(51, 102, 0));
        lblError.setText("-");
        jPanel3.add(lblError, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 40, 280, -1));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 590, 250));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 630, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 393, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        resetPassword();
    }//GEN-LAST:event_btnResetActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        txtEmail.setText("");
        txtPassword.setText("");
        txtRePassword.setText("");
        buttonGroup1.clearSelection();
    }//GEN-LAST:event_btnClearActionPerformed

    private void txtPasswordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtPasswordMouseClicked
        lblError.setText("");
    }//GEN-LAST:event_txtPasswordMouseClicked

    private void resetPassword() {
        String email = txtEmail.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();
        String repassword = new String(txtRePassword.getPassword()).trim();

        String role = null;
        if (rbParent.isSelected()) {
            role = "Parent";
        } else if (rbDriver.isSelected()) {
            role = "Driver";
        } else if (rbAdmin.isSelected()) {
            role = "Admin";
        } else if (rbDocSpecialist.isSelected()) {
            role = "Doc_specialist";
        }

        if (email.isEmpty() || password.isEmpty() || repassword.isEmpty() || role == null) {
            JOptionPane.showMessageDialog(this,
                    "Please fill all fields and select identification type!",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!password.equals(repassword)) {
            JOptionPane.showMessageDialog(this,
                    "Passwords do not match! Please re-enter.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            txtPassword.setText("");
            txtRePassword.setText("");
            return;
        }
        if (!ValidationUtils.isValidPassword(password)) {
    lblError.setText("<html>"
            + "Password must be at least 8 characters long<br>"
            + "Password must contain at least one uppercase letter<br>"
            + "Password must contain at least one lowercase letter<br>"
            + "Password must contain at least one digit<br>"
            + "Password must contain at least one special character<br>"
            + "Password cannot contain spaces"
            + "</html>");
            txtPassword.setText("");
            txtRePassword.setText("");            
            return;
        }

        boolean success = dbHelper.resetPassword(email, password, role);

        if (success) {
            JOptionPane.showMessageDialog(this,
                    "Password successfully updated!",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                    "No matching user found or update failed!",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new forgotPassword().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnReset;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblError;
    private javax.swing.JRadioButton rbAdmin;
    private javax.swing.JRadioButton rbDocSpecialist;
    private javax.swing.JRadioButton rbDriver;
    private javax.swing.JRadioButton rbParent;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JPasswordField txtRePassword;
    // End of variables declaration//GEN-END:variables
}
