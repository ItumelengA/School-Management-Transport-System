
public class ValidationUtils {

    public static boolean isValidEmail(String email) {
        // Simple email validation regex
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        return email.matches(emailRegex);
    }

    public static boolean isValidPassword(String password) {
        if (password == null) {
            return false;
        }
        // Minimum 8 characters
        if (password.length() < 8) {
            return false;
        }
        // Maximum 20 characters (optional)
        if (password.length() > 20) {
            return false;
        }
        // At least one uppercase letter
        if (!password.matches(".*[A-Z].*")) {
            return false;
        }
        // At least one lowercase letter
        if (!password.matches(".*[a-z].*")) {
            return false;
        }
        // At least one digit
        if (!password.matches(".*\\d.*")) {
            return false;
        }
        // At least one special character
        if (!password.matches(".*[!@#$%^&*()\\-_=+<>?].*")) {
            return false;
        }
        // No spaces allowed
        if (password.contains(" ")) {
            return false;
        }
        return true;
    }
}
