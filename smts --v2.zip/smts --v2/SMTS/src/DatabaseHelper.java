
import java.awt.Desktop;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class DatabaseHelper {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/smts_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "202303305@spu.ac.za";

    static {
        try {
            // Explicitly load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load MySQL JDBC driver", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    public static boolean emailExists(String email) {
        String query = "SELECT COUNT(*) FROM Login WHERE email = ?";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean createUser(User user) {
        String query = "INSERT INTO Login (email, password, user_role) VALUES (?, ?, ?)";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, user.getEmail());
            stmt.setString(2, user.getPassword()); // Note: In real app, store hashed password
            stmt.setString(3, user.getUserRole());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean isAdminEmail(String email) {
        String query = "SELECT COUNT(*) FROM Login WHERE email = ? AND user_role = 'admin'";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean validateUser(String email, String password, String user_role) {
        String query;

        if (user_role.equals("admin")) {
            // For admin, we only check email and password (role is already confirmed)
            query = "SELECT COUNT(*) FROM Login WHERE email = ? AND password = ?";
        } else {
            // For others, check email, password AND role
            query = "SELECT COUNT(*) FROM Login WHERE email = ? AND password = ? AND user_role = ?";
        }

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, email);
            stmt.setString(2, password);

            if (!user_role.equals("admin")) {
                stmt.setString(3, user_role);
            }

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    static boolean updatePassword(String email, String newPass, String role) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // Fetch driver names (already in your code)
    public List<String> getDriverNames() {
        List<String> names = new ArrayList<>();
        String sql = "SELECT Name FROM driver_registrations";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                names.add(rs.getString("Name"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return names;
    }

    //Load Driver details
    public Driver getDriverByName(String name) {
        Driver driver = null;
        // Modified query to join with Transport table
        String sql = "SELECT d.*, t.* FROM driver_registrations d "
                + "LEFT JOIN Transport t ON d.Driver_ID = t.Driver_ID "
                + "WHERE d.Name = ?";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                driver = new Driver();
                // Driver info
                driver.setFirstName(rs.getString("Name"));
                driver.setSurname(rs.getString("Surname"));
                driver.setPhone_number(rs.getString("Phone_number"));
                driver.setRate(rs.getDouble("Charge_amount_R"));
                driver.setTime_morning(rs.getString("Time_morning"));
                driver.setTime_afternoon(rs.getString("Time_afternoon"));
                driver.setSchoolName(rs.getString("School_name"));

                // Transport info (check for null since we used LEFT JOIN)
                if (rs.getBytes("License_pdf") != null) {
                    driver.setLicensePdf(rs.getBytes("License_pdf"));
                    driver.setPdfName(rs.getString("pdf_name"));
                    driver.setLicenseNumber(rs.getString("License_number"));
                    driver.setVehicleMake(rs.getString("Vehicle_make"));
                    driver.setVehicleModel(rs.getString("Vehicle_model"));  // Fixed typo from "Vehicle_mode"
                    driver.setVehicleYear(rs.getInt("Vehicle_year"));
                    driver.setVehicleRegistration(rs.getString("Vehicle_registration"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return driver;
    }

    public boolean savePayment(String firstName, String surname, double amount, String schoolName,
            String reference, java.sql.Date paidAt, int arrangementId, int parentId) {
        String sql = "INSERT INTO Payment (Driver_name, Driver_surname, Amount_R, School_name, Reference, Paid_at, Arrangement_ID, Parent_ID) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, firstName);
            stmt.setString(2, surname);
            stmt.setDouble(3, amount);
            stmt.setString(4, schoolName);
            stmt.setString(5, reference);
            stmt.setDate(6, paidAt);
            stmt.setInt(7, arrangementId);
            stmt.setInt(8, parentId);

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static Parent getParentByEmail(String email) {
        Parent parent = null;
        String loginQuery = "SELECT Login_ID FROM Login WHERE email = ?";
        String parentQuery = "SELECT * FROM Parent WHERE Login_ID = ?";

        try (Connection conn = getConnection(); PreparedStatement loginStmt = conn.prepareStatement(loginQuery); PreparedStatement parentStmt = conn.prepareStatement(parentQuery)) {

            // Get Login_ID first
            loginStmt.setString(1, email);
            ResultSet loginRs = loginStmt.executeQuery();

            if (loginRs.next()) {
                int loginId = loginRs.getInt("Login_ID");

                // Now get parent info
                parentStmt.setInt(1, loginId);
                ResultSet parentRs = parentStmt.executeQuery();

                if (parentRs.next()) {
                    parent = new Parent();
                    parent.setParentId(parentRs.getInt("Parent_ID"));
                    parent.setLoginId(loginId); // ← ADD THIS LINE
                    parent.setName(parentRs.getString("Name"));
                    parent.setSurname(parentRs.getString("Surname"));
                    parent.setEmail(email);
                    parent.setPhone_number(parentRs.getString("Phone_number"));
                    parent.setEmergency_number(parentRs.getString("Emergency_number"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return parent;
    }

    public static List<Driver> getAllDrivers() {
        List<Driver> drivers = new ArrayList<>();

        String query = "SELECT l.Login_ID, l.Email, l.User_role,l.Password, "
                + "d.Driver_ID, d.Name, d.Surname, d.Phone_number, d.School_name, "
                + "d.Time_morning, d.Time_afternoon, d.Charge_amount_R, "
                + "t.Transport_ID, t.pdf_name, t.License_number, t.Vehicle_make, "
                + "t.Vehicle_model, t.Vehicle_year, t.Vehicle_registration "
                + "FROM Login l "
                + "JOIN driver_registrations d ON l.Login_ID = d.Login_ID "
                + "JOIN Transport t ON d.Driver_ID = t.Driver_ID";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Driver driver = new Driver();
                // Driver info
                driver.setDriverId(rs.getInt("Driver_ID"));
                driver.setFirstName(rs.getString("Name"));
                driver.setSurname(rs.getString("Surname"));
                driver.setPhone_number(rs.getString("Phone_number"));
                driver.setSchoolName(rs.getString("School_name"));
                driver.setTime_morning(rs.getString("Time_morning"));
                driver.setTime_afternoon(rs.getString("Time_afternoon"));
                driver.setRate(rs.getDouble("Charge_amount_R"));
                driver.setEmail(rs.getString("Email"));
                driver.setPassword(rs.getString("Password"));

                // Transport info
                driver.setTransportId(rs.getInt("Transport_ID"));
                driver.setPdfName(rs.getString("pdf_name"));
                driver.setLicenseNumber(rs.getString("License_number"));
                driver.setVehicleMake(rs.getString("Vehicle_make"));
                driver.setVehicleModel(rs.getString("Vehicle_model"));
                driver.setVehicleYear(rs.getInt("Vehicle_year"));
                driver.setVehicleRegistration(rs.getString("Vehicle_registration"));

                drivers.add(driver);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return drivers;
    }

    //view pdf
    public static byte[] getDriverLicensePdf(int driverId) throws SQLException {
        String sql = "SELECT License_pdf FROM Transport WHERE Driver_ID = ?";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, driverId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getBytes("License_pdf");
            }
        }
        return null;
    }

    public static Driver getDriverByEmail(String email) {
        Driver driver = null;

        String sql = "SELECT d.*, l.Email, l.Login_ID, t.* FROM driver_registrations d "
                + "JOIN Login l ON d.Login_ID = l.Login_ID " // join with Login
                + "LEFT JOIN Transport t ON d.Driver_ID = t.Driver_ID " // keep your transport info
                + "WHERE l.Email = ?";   // use email from Login table

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                driver = new Driver();
                // Driver info - ADD THESE TWO LINES
                driver.setDriverId(rs.getInt("Driver_ID"));
                driver.setLoginId(rs.getInt("Login_ID"));

                driver.setFirstName(rs.getString("Name"));
                driver.setSurname(rs.getString("Surname"));
                driver.setPhone_number(rs.getString("Phone_number"));
                driver.setRate(rs.getDouble("Charge_amount_R"));
                driver.setTime_morning(rs.getString("Time_morning"));
                driver.setTime_afternoon(rs.getString("Time_afternoon"));
                driver.setSchoolName(rs.getString("School_name"));
                driver.setEmail(rs.getString("Email")); // comes from Login

                // Transport info
                if (rs.getBytes("License_pdf") != null) {
                    driver.setLicensePdf(rs.getBytes("License_pdf"));
                    driver.setPdfName(rs.getString("pdf_name"));
                    driver.setLicenseNumber(rs.getString("License_number"));
                    driver.setVehicleMake(rs.getString("Vehicle_make"));
                    driver.setVehicleModel(rs.getString("Vehicle_model"));
                    driver.setVehicleYear(rs.getInt("Vehicle_year"));
                    driver.setVehicleRegistration(rs.getString("Vehicle_registration"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return driver;
    }

    // Insert Learner
    public static boolean childRegisiter(String name, String midName, String surname,
            java.sql.Date dob, int age, String schoolName,
            String pickup, String dropoff, String medicalCondition,
            int parentId) {
        String sql = "INSERT INTO Learner(Name, MidName, Surname, DateOfBirth, Age, ScholName, Pickup_Location, Dropoff_Location, MedicalCondition, Parent_ID) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"; // Changed to 10 parameters

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, midName);
            stmt.setString(3, surname);
            stmt.setDate(4, dob);
            stmt.setInt(5, age);
            stmt.setString(6, schoolName);
            stmt.setString(7, pickup);
            stmt.setString(8, dropoff);
            stmt.setString(9, medicalCondition);
            stmt.setInt(10, parentId);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static int getParentIdByLoginId(int loginId) {
        String query = "SELECT Parent_ID FROM Parent WHERE Login_ID = ?";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, loginId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("Parent_ID");
            }
            return -1; // Parent not found
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    public static boolean updateParent(int parentId, String name, String surname, String phoneNumber,
            String emergencyNumber, String relationship) {
        String updateSql = "UPDATE Parent SET Name = ?, Surname = ?, Phone_number = ?, "
                + "Emergency_number = ?, Relationship = ? WHERE Parent_ID = ?";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(updateSql)) {

            stmt.setString(1, name);
            stmt.setString(2, surname);
            stmt.setString(3, phoneNumber);
            stmt.setString(4, emergencyNumber);
            stmt.setString(5, relationship);
            stmt.setInt(6, parentId);

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static int insertParent(String name, String surname, String phoneNumber, String emergencyNumber,
            String relationship, int loginId) {
        String insertSql = "INSERT INTO Parent (Name, Surname, Phone_number, Emergency_number, Relationship, Login_ID) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, name);
            stmt.setString(2, surname);
            stmt.setString(3, phoneNumber);
            stmt.setString(4, emergencyNumber);
            stmt.setString(5, relationship);
            stmt.setInt(6, loginId);

            int rows = stmt.executeUpdate();

            if (rows > 0) {
                // Get the generated parent ID
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    return rs.getInt(1); // Return the generated parent ID
                }
            }
            return -1; // Indicate failure
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }

    }

    public static int getLoginIdByEmail(String email) {
        String query = "SELECT Login_ID FROM Login WHERE email = ?";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("Login_ID");
            }
            return -1; // Login ID not found
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    public static boolean saveReview(String parentName, String driverName, String comment) {
        String sql = "INSERT INTO Reviews (Parent_Name, Driver_Name, Comment, Review_Date) "
                + "VALUES (?, ?, ?, ?)";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, parentName);
            stmt.setString(2, driverName);
            stmt.setString(3, comment);
            stmt.setDate(4, new java.sql.Date(System.currentTimeMillis()));

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error saving review: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    //Driver register
    public static int insertDriverAndTransport(
            String name, String surname, String phoneNumber, String schoolName,
            String timeMorning, String timeAfternoon, double chargeAmount, int loginId,
            byte[] licensePdf, String pdfName, String licenseNumber, String vehicleMake,
            String vehicleModel, int vehicleYear, String vehicleRegistration) {

        String driverSql = "INSERT INTO driver_registrations (Name, Surname, Phone_number, School_name, Time_morning, Time_afternoon, Charge_amount_R, Login_ID) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        String transportSql = "INSERT INTO Transport (License_pdf, pdf_name, License_number, Vehicle_make, Vehicle_model, Vehicle_year, Vehicle_registration, Driver_ID) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false); // Begin transaction

            // Step 1: Insert driver
            int driverId = -1;
            try (PreparedStatement stmt = conn.prepareStatement(driverSql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, name);
                stmt.setString(2, surname);
                stmt.setString(3, phoneNumber);
                stmt.setString(4, schoolName);
                stmt.setString(5, timeMorning);
                stmt.setString(6, timeAfternoon);
                stmt.setDouble(7, chargeAmount);
                stmt.setInt(8, loginId);

                int rows = stmt.executeUpdate();
                if (rows > 0) {
                    ResultSet rs = stmt.getGeneratedKeys();
                    if (rs.next()) {
                        driverId = rs.getInt(1);
                    }
                }
            }

            if (driverId == -1) {
                conn.rollback();
                return -1; // failed
            }

            // Step 2: Insert transport
            try (PreparedStatement stmt2 = conn.prepareStatement(transportSql, Statement.RETURN_GENERATED_KEYS)) {
                stmt2.setBytes(1, licensePdf);
                stmt2.setString(2, pdfName);
                stmt2.setString(3, licenseNumber);
                stmt2.setString(4, vehicleMake);
                stmt2.setString(5, vehicleModel);
                stmt2.setInt(6, vehicleYear);
                stmt2.setString(7, vehicleRegistration);
                stmt2.setInt(8, driverId);

                int rows2 = stmt2.executeUpdate();
                if (rows2 > 0) {
                    conn.commit(); // Both inserts succeeded
                    return driverId;
                } else {
                    conn.rollback();
                    return -1;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    public static boolean saveArrangement(int driverId, String driverName, String driverSurname,
            int parentId, String parentName, String parentSurname,
            int learnerId, String learnerName, String learnerSurname,
            String pickup, String dropoff,
            String timeMorning, String timeAfternoon,
            String schoolName) {

        String query = "INSERT INTO Arrangement (Driver_ID, Driver_Name, Driver_Surname, "
                + "Parent_ID, Parent_Name, Parent_Surname, "
                + "Learner_ID, Learner_Name, Learner_Surname, "
                + "Pickup_Location, Dropoff_Location, "
                + "Time_Morning, Time_Afternoon, School_Name, Arrangement_Date, Status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), 'Pending')";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, driverId);
            stmt.setString(2, driverName);
            stmt.setString(3, driverSurname);
            stmt.setInt(4, parentId);
            stmt.setString(5, parentName);
            stmt.setString(6, parentSurname);
            stmt.setInt(7, learnerId);
            stmt.setString(8, learnerName);
            stmt.setString(9, learnerSurname);
            stmt.setString(10, pickup);
            stmt.setString(11, dropoff);

            if (timeMorning != null && !timeMorning.trim().isEmpty()) {
                stmt.setTime(12, java.sql.Time.valueOf(timeMorning));
            } else {
                stmt.setNull(12, java.sql.Types.TIME);
            }

            if (timeAfternoon != null && !timeAfternoon.trim().isEmpty()) {
                stmt.setTime(13, java.sql.Time.valueOf(timeAfternoon));
            } else {
                stmt.setNull(13, java.sql.Types.TIME);
            }

            stmt.setString(14, schoolName);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Parent> getAllParents() {
        List<Parent> parents = new ArrayList<>();
        String sql = "SELECT Parent_ID, Name, Surname, Phone_number, Emergency_number, Relationship FROM Parent";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Parent parent = new Parent();
                parent.setParentId(rs.getInt("Parent_ID"));
                parent.setName(rs.getString("Name"));
                parent.setSurname(rs.getString("Surname"));
                parent.setPhone_number(rs.getString("Phone_number"));
                parent.setEmergency_number(rs.getString("Emergency_number"));
                parent.setRelationship(rs.getString("Relationship"));

                parents.add(parent);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return parents;
    }

    public int getArrangementIdForParent(int parentId) {
        int arrangementId = -1;
        String sql = "SELECT Arrangement_ID FROM Arrangement WHERE Parent_ID = ? ORDER BY Arrangement_Date DESC LIMIT 1";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, parentId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    arrangementId = rs.getInt("Arrangement_ID");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return arrangementId;
    }

    public List<UserInfor> getAllUsersWithoutDates() {
        List<UserInfor> users = new ArrayList<>();
        String query = "SELECT l.Login_ID, l.Email, 'Parent' AS Role, "
                + "p.Name AS User_Name, p.Surname AS User_Surname, "
                + "le.Name AS Child_Name, le.Surname AS Child_Surname "
                + "FROM Login l "
                + "JOIN Parent p ON l.Login_ID = p.Login_ID "
                + "LEFT JOIN Learner le ON p.Parent_ID = le.Parent_ID "
                + "UNION "
                + "SELECT l.Login_ID, l.Email, 'Driver' AS Role, "
                + "d.Name AS User_Name, d.Surname AS User_Surname, "
                + "NULL AS Child_Name, NULL AS Child_Surname "
                + "FROM Login l "
                + "JOIN driver_registrations d ON l.Login_ID = d.Login_ID";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                UserInfor u = new UserInfor();
                u.setLoginId(rs.getInt("Login_ID"));
                u.setEmail(rs.getString("Email"));
                u.setRole(rs.getString("Role"));
                u.setName(rs.getString("User_Name"));
                u.setSurname(rs.getString("User_Surname"));
                u.setChildName(rs.getString("Child_Name"));
                u.setChildSurname(rs.getString("Child_Surname"));

                users.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return users;
    }

    public boolean resetPassword(String email, String newPassword, String role) {
        String sql = "UPDATE Login SET Password = ? WHERE Email = ? AND User_Role = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, newPassword);
            ps.setString(2, email);
            ps.setString(3, role);

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static Parent getParentProfile(int loginId) {
        // Updated query to JOIN with Login table to get email
        String sql = "SELECT p.Parent_ID, p.Name, p.Surname, p.Phone_number, "
                + "p.Emergency_number, p.Relationship, l.Email "
                + "FROM Parent p "
                + "JOIN Login l ON p.Login_ID = l.Login_ID "
                + "WHERE p.Login_ID = ?";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, loginId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Parent parentClass = new Parent();

                    parentClass.setParentId(rs.getInt("Parent_ID"));
                    parentClass.setLoginId(loginId);  // Set the login ID
                    parentClass.setName(rs.getString("Name"));
                    parentClass.setSurname(rs.getString("Surname"));
                    parentClass.setPhone_number(rs.getString("Phone_number"));
                    parentClass.setEmergency_number(rs.getString("Emergency_number"));
                    parentClass.setRelationship(rs.getString("Relationship"));
                    parentClass.setEmail(rs.getString("Email"));

                    return parentClass;
                } else {
                    return null;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static int getSpecialistIdByLoginId(int loginId) {
        int specialistId = -1;
        String query = "SELECT specialist_id FROM document_specialist WHERE Login_ID = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, loginId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                specialistId = rs.getInt("specialist_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return specialistId;
    }

    public static int getDriverIdByEmail(String email) {
        String sql = "SELECT Driver_ID FROM driver_registrations WHERE Email = ?";
        try (Connection conn = getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, email);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return rs.getInt("Driver_ID");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    public static void openDocument(String fileName) {
        try {
            if (fileName == null || fileName.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No file linked to this record.");
                return;
            }

            File file = new File("Documents", fileName); // Always Documents folder
            if (file.exists()) {
                Desktop.getDesktop().open(file);
            } else {
                JOptionPane.showMessageDialog(null, "File not found: " + file.getAbsolutePath());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error opening file: " + ex.getMessage());
        }
    }

    public static String getAccountStatusByEmail(String email) {
        String status = null;
        String query = "SELECT Account_status FROM Login WHERE Email = ?";

        try (java.sql.Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    status = rs.getString("Account_status");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return status;
    }

    public static boolean cancelArrangement(int parentId) {
        String sql = "DELETE FROM Arrangement WHERE Learner_ID IN (SELECT Learner_ID FROM Learner WHERE Parent_ID = ?)";
        try (Connection conn = DatabaseHelper.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, parentId);
            int rowsAffected = pst.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static Driver getDriverByID(int loginId) {
        String sql = "SELECT d.Driver_ID, d.Name, d.Surname, d.Phone_number, d.School_name, "
                + "d.Time_morning, d.Time_afternoon, d.Charge_amount_R, d.Login_ID, "
                + "t.Transport_ID, t.License_pdf, t.pdf_name, t.License_number, "
                + "t.Vehicle_make, t.Vehicle_model, t.Vehicle_year, t.Vehicle_registration, t.Registration_date "
                + "FROM driver_registrations d "
                + "LEFT JOIN Transport t ON d.Driver_ID = t.Driver_ID "
                + "WHERE d.Login_ID = ?";

        System.out.println("Querying driver with Login_ID: " + loginId); // Debug line

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, loginId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Driver driver = new Driver();
                    driver.setDriverId(rs.getInt("Driver_ID"));
                    driver.setFirstName(rs.getString("Name"));
                    driver.setSurname(rs.getString("Surname"));
                    driver.setPhone_number(rs.getString("Phone_number"));
                    driver.setSchoolName(rs.getString("School_name"));
                    driver.setTime_morning(rs.getString("Time_morning"));
                    driver.setTime_afternoon(rs.getString("Time_afternoon"));
                    driver.setRate(rs.getDouble("Charge_amount_R"));
                    driver.setLoginId(rs.getInt("Login_ID"));

                    // Transport Info
                    driver.setTransportId(rs.getInt("Transport_ID"));
                    driver.setPdfName(rs.getString("pdf_name"));
                    driver.setLicenseNumber(rs.getString("License_number"));
                    driver.setVehicleMake(rs.getString("Vehicle_make"));
                    driver.setVehicleModel(rs.getString("Vehicle_model"));
                    driver.setVehicleYear(rs.getInt("Vehicle_year"));
                    driver.setVehicleRegistration(rs.getString("Vehicle_registration"));
                    // FIXED: Don't overwrite Vehicle_registration
                    // driver.setRegistrationDate(rs.getString("Registration_date")); // If this field exists
                    driver.setLicensePdf(rs.getBytes("License_pdf"));

                    System.out.println("Driver found: Driver_ID=" + driver.getDriverId()
                            + ", Name=" + driver.getFirstName()); // Debug line
                    return driver;
                } else {
                    System.out.println("No driver found in database for Login_ID: " + loginId); // Debug line
                }
            }
        } catch (SQLException e) {
            System.err.println("SQL Error in getDriverByID: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}
