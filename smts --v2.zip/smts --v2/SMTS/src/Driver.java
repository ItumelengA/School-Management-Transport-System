public class Driver {

    private String firstName;
    private String surname;
    private String phone_number;
    private double rate;
    private String schoolName;
    private String time_morning;
    private String time_afternoon;
    private String email;
    private String password;
    private int schoolId;
    private int driverId;
    private int loginId; ;
    //Transport
    private byte[] licensePdf;
    private String pdfName;
    private String licenseNumber;
    private String vehicleMake;
    private String vehicleModel;
    private int vehicleYear;
    private String vehicleRegistration;
    private int transportId;
    
    
    public int getLoginId() {
        return loginId;
    }

    // Getters and setters
    public void setLoginId(int loginId) {
        this.loginId = loginId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public int getSchoolId() {
        return schoolId;
    }

    public void setSchoolId(int schoolId) {
        this.schoolId = schoolId;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getTime_morning() {
        return time_morning;
    }

    public void setTime_morning(String time_morning) {
        this.time_morning = time_morning;
    }

    public String getTime_afternoon() {
        return time_afternoon;
    }

    public void setTime_afternoon(String time_afternoon) {
        this.time_afternoon = time_afternoon;
    }

    public byte[] getLicensePdf() {
        return licensePdf;
    }

    public void setLicensePdf(byte[] licensePdf) {
        this.licensePdf = licensePdf;
    }

    public String getPdfName() {
        return pdfName;
    }

    public void setPdfName(String pdfName) {
        this.pdfName = pdfName;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public String getVehicleMake() {
        return vehicleMake;
    }

    public void setVehicleMake(String vehicleMake) {
        this.vehicleMake = vehicleMake;
    }

    public String getVehicleModel() {
        return vehicleModel;
    }

    public void setVehicleModel(String vehicleModel) {
        this.vehicleModel = vehicleModel;
    }

    public int getVehicleYear() {
        return vehicleYear;
    }

    public void setVehicleYear(int vehicleYear) {
        this.vehicleYear = vehicleYear;
    }

    public String getVehicleRegistration() {
        return vehicleRegistration;
    }

    public void setVehicleRegistration(String vehicleRegistration) {
        this.vehicleRegistration = vehicleRegistration;
    }

    public int getTransportId() {
        return transportId;
    }

    public void setTransportId(int transportId) {
        this.transportId = transportId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getDriverId() {
        return driverId;
    }

    public void setDriverId(int driverId) {
        this.driverId = driverId;
    }
    

}
