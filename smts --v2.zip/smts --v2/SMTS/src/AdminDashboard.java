
import java.awt.Color;
import javax.swing.JLabel;

public class AdminDashboard extends javax.swing.JFrame {

    private DatabaseHelper dbHelper = new DatabaseHelper();
    private JLabel selectedLabel;

    public AdminDashboard() {
        initComponents();

        jDesktopPane1.removeAll();
        ViewReviews panel = new ViewReviews();
        panel.setBounds(0, 0, jDesktopPane1.getWidth(), jDesktopPane1.getHeight());
        jDesktopPane1.add(panel);
        jDesktopPane1.revalidate();
        jDesktopPane1.repaint();
        setActiveLabel(lblReviews);

    }

    private void setActiveLabel(JLabel label) {
        Color baseColor = new Color(0, 19, 34);   // default sidebar background
        Color activeColor = new Color(0, 51, 102); // highlight when selected

        // reset the previous label
        if (selectedLabel != null) {
            selectedLabel.setOpaque(true);
            selectedLabel.setBackground(baseColor);
        }

        // set new active label
        label.setOpaque(true);
        label.setBackground(activeColor);
        selectedLabel = label;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblReviews = new javax.swing.JLabel();
        lblManageProfile = new javax.swing.JLabel();
        lblRegisteredUsers = new javax.swing.JLabel();
        lblManageUsers = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lblGenerateQr = new javax.swing.JLabel();
        lblLogout = new javax.swing.JLabel();
        lblReports = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        jPanel5 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 19, 34));

        lblReviews.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lblReviews.setForeground(new java.awt.Color(255, 255, 255));
        lblReviews.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblReviews.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/revi.png"))); // NOI18N
        lblReviews.setText("View Reviews");
        lblReviews.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblReviewsMouseClicked(evt);
            }
        });

        lblManageProfile.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lblManageProfile.setForeground(new java.awt.Color(255, 255, 255));
        lblManageProfile.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblManageProfile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/profile_image.png"))); // NOI18N
        lblManageProfile.setText("Manage Profile");
        lblManageProfile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblManageProfileMouseClicked(evt);
            }
        });

        lblRegisteredUsers.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lblRegisteredUsers.setForeground(new java.awt.Color(255, 255, 255));
        lblRegisteredUsers.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblRegisteredUsers.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/register_user.png"))); // NOI18N
        lblRegisteredUsers.setText("View Registered Users");
        lblRegisteredUsers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRegisteredUsersMouseClicked(evt);
            }
        });

        lblManageUsers.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lblManageUsers.setForeground(new java.awt.Color(255, 255, 255));
        lblManageUsers.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblManageUsers.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/user_settings.png"))); // NOI18N
        lblManageUsers.setText("Manage Users");
        lblManageUsers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblManageUsersMouseClicked(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N
        jLabel4.setText("MENU");

        lblGenerateQr.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lblGenerateQr.setForeground(new java.awt.Color(255, 255, 255));
        lblGenerateQr.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblGenerateQr.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/qr_code.png"))); // NOI18N
        lblGenerateQr.setText("Generate QR Codes");
        lblGenerateQr.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGenerateQrMouseClicked(evt);
            }
        });

        lblLogout.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lblLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblLogout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/logout.png"))); // NOI18N
        lblLogout.setText("Logout");
        lblLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLogoutMouseClicked(evt);
            }
        });

        lblReports.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lblReports.setForeground(new java.awt.Color(255, 255, 255));
        lblReports.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblReports.setText("Reports");
        lblReports.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblReportsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(lblManageUsers, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblGenerateQr, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLogout, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblRegisteredUsers, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblManageProfile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblReviews, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblReports, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblReviews, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblManageProfile, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblRegisteredUsers, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblManageUsers, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblGenerateQr, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblReports, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 135, Short.MAX_VALUE)
                .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.LINE_START);

        jPanel2.setBackground(new java.awt.Color(0, 51, 102));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(0, 51, 102));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/bus_logo.png"))); // NOI18N
        jLabel9.setText("Safe Rides");
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 150, 40));

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1270, 60));

        getContentPane().add(jPanel2, java.awt.BorderLayout.PAGE_START);

        jPanel3.setBackground(new java.awt.Color(0, 51, 102));

        jLabel8.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("School Ride | © 2025 | Follow us on Twitter @SchoolRideApp");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(561, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(267, 267, 267))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel8)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, java.awt.BorderLayout.PAGE_END);

        jDesktopPane1.setBackground(new java.awt.Color(255, 255, 255));
        jDesktopPane1.setMaximumSize(new java.awt.Dimension(1380, 694));
        jDesktopPane1.setPreferredSize(new java.awt.Dimension(1380, 694));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setLayout(new javax.swing.BoxLayout(jPanel5, javax.swing.BoxLayout.LINE_AXIS));

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setPreferredSize(new java.awt.Dimension(1200, 1000));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1070, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 571, Short.MAX_VALUE)
        );

        jDesktopPane1.setLayer(jPanel5, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jPanel7, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 1070, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(532, 532, 532)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap(127, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(444, 444, 444))
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, 571, Short.MAX_VALUE)
        );

        getContentPane().add(jDesktopPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblReviewsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblReviewsMouseClicked
        jDesktopPane1.removeAll();
        ViewReviews panel = new ViewReviews();
        panel.setBounds(0, 0, jDesktopPane1.getWidth(), jDesktopPane1.getHeight());
        jDesktopPane1.add(panel);
        jDesktopPane1.revalidate();
        jDesktopPane1.repaint();
        setActiveLabel(lblReviews);
    }//GEN-LAST:event_lblReviewsMouseClicked

    private void lblManageProfileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblManageProfileMouseClicked
        jDesktopPane1.removeAll();
        ManageAdminAcc panel = new ManageAdminAcc();
        panel.setBounds(0, 0, jDesktopPane1.getWidth(), jDesktopPane1.getHeight());
        jDesktopPane1.add(panel);
        jDesktopPane1.revalidate();
        jDesktopPane1.repaint();
        setActiveLabel(lblManageProfile);
    }//GEN-LAST:event_lblManageProfileMouseClicked

    private void lblRegisteredUsersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRegisteredUsersMouseClicked
        jDesktopPane1.removeAll();
        registeredUsers panel = new registeredUsers(dbHelper);
        panel.setBounds(0, 0, jDesktopPane1.getWidth(), jDesktopPane1.getHeight());
        jDesktopPane1.add(panel);
        jDesktopPane1.revalidate();
        jDesktopPane1.repaint();
        setActiveLabel(lblRegisteredUsers);
    }//GEN-LAST:event_lblRegisteredUsersMouseClicked

    private void lblManageUsersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblManageUsersMouseClicked
        jDesktopPane1.removeAll();
        ManageregisteredUsers panel = new ManageregisteredUsers();
        panel.setBounds(0, 0, jDesktopPane1.getWidth(), jDesktopPane1.getHeight());
        jDesktopPane1.add(panel);
        jDesktopPane1.revalidate();
        jDesktopPane1.repaint();
        setActiveLabel(lblManageUsers);
    }//GEN-LAST:event_lblManageUsersMouseClicked

    private void lblGenerateQrMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGenerateQrMouseClicked
        jDesktopPane1.removeAll();
        Qr_codes panel = new Qr_codes();
        panel.setBounds(0, 0, jDesktopPane1.getWidth(), jDesktopPane1.getHeight());
        jDesktopPane1.add(panel);
        jDesktopPane1.revalidate();
        jDesktopPane1.repaint();
        panel.setVisible(true);
        setActiveLabel(lblGenerateQr);
    }//GEN-LAST:event_lblGenerateQrMouseClicked

    private void lblLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLogoutMouseClicked

        logout();
        setActiveLabel(lblLogout);
    }

    private void logout() {
        // Close current dashboard
        dispose();

        // Open login form again
        Login loginForm = new Login();  // ✅ Correct class name
        loginForm.setVisible(true);
        loginForm.setLocationRelativeTo(null); // center on screen


    }//GEN-LAST:event_lblLogoutMouseClicked

    private void lblReportsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblReportsMouseClicked
        jDesktopPane1.removeAll();
        reports panel = new reports();
        panel.setBounds(0, 0, jDesktopPane1.getWidth(), jDesktopPane1.getHeight());
        jDesktopPane1.add(panel);
        jDesktopPane1.revalidate();
        jDesktopPane1.repaint();
        panel.setVisible(true);
        setActiveLabel(lblReports);
    }//GEN-LAST:event_lblReportsMouseClicked

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminDashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JLabel lblGenerateQr;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JLabel lblManageProfile;
    private javax.swing.JLabel lblManageUsers;
    private javax.swing.JLabel lblRegisteredUsers;
    private javax.swing.JLabel lblReports;
    private javax.swing.JLabel lblReviews;
    // End of variables declaration//GEN-END:variables
}
