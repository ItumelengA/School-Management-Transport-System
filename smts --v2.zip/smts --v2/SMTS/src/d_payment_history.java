
import javax.swing.JSlider;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class d_payment_history extends javax.swing.JPanel {

    private DatabaseHelper dbHelper;
    private Driver loggedInDriver;

    public d_payment_history(Driver driver) {
        this.loggedInDriver = driver;
        initComponents();

        loadData(txtsearch_name.getText().trim(), loggedInDriver);

        cmbDateFilter.addActionListener(e -> {
            String parentName = txtsearch_name.getText().trim();
            loadData(parentName, loggedInDriver);
        });

        cmbDateFilter.addItem("- Choose a Date Range -");
        cmbDateFilter.addItem("All");
        cmbDateFilter.addItem("Today");
        cmbDateFilter.addItem("Last 7 Days");
        cmbDateFilter.addItem("Last 30 Days");
        cmbDateFilter.addItem("This Month");
        cmbDateFilter.addItem("This Year");
    }

    public void setLoggedInDriver(Driver driver) {
        this.loggedInDriver = driver;
    }

    private void loadData(String parentName, Driver driver) {
        if (driver == null) {
            JOptionPane.showMessageDialog(this, "No driver is logged in");
            return;
        }

        try (Connection con = DatabaseHelper.getConnection()) {
            StringBuilder sql = new StringBuilder(
                    "SELECT p.Payment_ID, p.Driver_name, p.Driver_surname, p.Amount_R, "
                    + "p.School_name, p.Reference, p.Paid_at, "
                    + "pa.Name AS ParentName, pa.Surname AS ParentSurname, "
                    + "l.Name AS ChildName, l.Surname AS ChildSurname "
                    + "FROM Payment p "
                    + "JOIN Parent pa ON p.Parent_ID = pa.Parent_ID "
                    + "JOIN Arrangement a ON p.Arrangement_ID = a.Arrangement_ID "
                    + "JOIN Learner l ON a.Learner_ID = l.Learner_ID "
                    + "WHERE p.Driver_name = ? AND p.Driver_surname = ?"
            );

            boolean hasParent = parentName != null && !parentName.trim().isEmpty();
            if (hasParent) {
                sql.append(" AND (pa.Name LIKE ? OR pa.Surname LIKE ?)");
            }

            //Date filter from combo
            String dateFilter = (String) cmbDateFilter.getSelectedItem();
            if (dateFilter != null && !"All".equals(dateFilter)) {
                switch (dateFilter) {
                    case "Today":
                        sql.append(" AND DATE(p.Paid_at) = CURDATE()");
                        break;
                    case "Last 7 Days":
                        sql.append(" AND DATE(p.Paid_at) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)");
                        break;
                    case "Last 30 Days":
                        sql.append(" AND DATE(p.Paid_at) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)");
                        break;
                    case "This Month":
                        sql.append(" AND MONTH(p.Paid_at) = MONTH(CURDATE()) "
                                + "AND YEAR(p.Paid_at) = YEAR(CURDATE())");
                        break;
                    case "This Year":
                        sql.append(" AND YEAR(p.Paid_at) = YEAR(CURDATE())");
                        break;
                }
            }

            PreparedStatement stmt = con.prepareStatement(sql.toString());
            stmt.setString(1, driver.getFirstName());
            stmt.setString(2, driver.getSurname());

            if (hasParent) {
                stmt.setString(3, "%" + parentName.trim() + "%");
                stmt.setString(4, "%" + parentName.trim() + "%");
            }

            ResultSet rs = stmt.executeQuery();

            // ---------- build cards ----------
            jpanel_paydates.removeAll();
            jpanel_paydates.setLayout(new BoxLayout(jpanel_paydates, BoxLayout.Y_AXIS));
            jpanel_paydates.setBackground(new Color(240, 240, 240));
            jpanel_paydates.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            boolean hasResults = false;

            while (rs.next()) {
                hasResults = true;

                JPanel card = new JPanel(new BorderLayout(15, 15));
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                        BorderFactory.createEmptyBorder(20, 20, 20, 20)
                ));
                card.setBackground(Color.WHITE);
                card.setMaximumSize(new Dimension(650, 160));
                card.setPreferredSize(new Dimension(650, 160));

                JPanel contentPanel = new JPanel();
                contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
                contentPanel.setOpaque(false);

                int paymentId = rs.getInt("Payment_ID");
                String parentFullName = rs.getString("ParentName") + " " + rs.getString("ParentSurname");
                String childFullName = rs.getString("ChildName") + " " + rs.getString("ChildSurname");
                double amount = rs.getDouble("Amount_R");
                String school = rs.getString("School_name");
                String reference = rs.getString("Reference");
                Timestamp paidAt = rs.getTimestamp("Paid_at");

                JLabel lblTitle = new JLabel("Payment #" + paymentId);
                lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
                lblTitle.setForeground(new Color(128, 0, 128));

                JLabel lblParent = new JLabel("Parent: " + parentFullName);
                JLabel lblChild = new JLabel("Child: " + childFullName);
                JLabel lblAmount = new JLabel("Amount: R" + amount);
                JLabel lblSchool = new JLabel("School: " + school);
                JLabel lblReference = new JLabel("Reference: " + reference);
                JLabel lblDate = new JLabel("Paid at: " + paidAt.toString());

                contentPanel.add(lblTitle);
                contentPanel.add(lblParent);
                contentPanel.add(lblChild);
                contentPanel.add(lblAmount);
                contentPanel.add(lblSchool);
                contentPanel.add(lblReference);
                contentPanel.add(lblDate);

                card.add(contentPanel, BorderLayout.CENTER);
                jpanel_paydates.add(card);
                jpanel_paydates.add(Box.createRigidArea(new Dimension(0, 15)));
            }

            if (!hasResults) {
                JPanel emptyPanel = new JPanel(new BorderLayout());
                emptyPanel.setBackground(Color.WHITE);
                emptyPanel.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                        BorderFactory.createEmptyBorder(40, 40, 40, 40)
                ));
                emptyPanel.setPreferredSize(new Dimension(650, 160));

                // optional icon
                JLabel lblIcon = new JLabel(new ImageIcon(getClass().getResource("/icons/empty.png")));
                lblIcon.setHorizontalAlignment(SwingConstants.CENTER);

                JLabel lblEmpty = new JLabel("No payments yet");
                lblEmpty.setFont(new Font("Segoe UI", Font.BOLD, 18));
                lblEmpty.setForeground(new Color(150, 150, 150));
                lblEmpty.setHorizontalAlignment(SwingConstants.CENTER);

                JPanel content = new JPanel();
                content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
                content.setOpaque(false);
                content.add(lblIcon);
                content.add(Box.createRigidArea(new Dimension(0, 10)));
                content.add(lblEmpty);

                emptyPanel.add(content, BorderLayout.CENTER);

                jpanel_paydates.setLayout(new GridBagLayout()); // center in the panel
                jpanel_paydates.add(emptyPanel);
            }

            jScrollPane1.setViewportView(jpanel_paydates);
            jpanel_paydates.revalidate();
            jpanel_paydates.repaint();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtsearch_name = new javax.swing.JTextField();
        btn_search = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jpanel_paydates = new javax.swing.JPanel();
        btn_reminder = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        cmbDateFilter = new javax.swing.JComboBox<>();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(1086, 630));
        jPanel1.setMinimumSize(new java.awt.Dimension(1086, 630));
        jPanel1.setPreferredSize(new java.awt.Dimension(1086, 630));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI Variable", 1, 18)); // NOI18N
        jLabel1.setText("Monthly Payment Overview");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(347, 60, -1, -1));

        txtsearch_name.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jPanel1.add(txtsearch_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, 205, 30));

        btn_search.setBackground(new java.awt.Color(0, 102, 255));
        btn_search.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        btn_search.setForeground(new java.awt.Color(255, 255, 255));
        btn_search.setText("Search");
        btn_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchActionPerformed(evt);
            }
        });
        jPanel1.add(btn_search, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 110, -1, 30));

        jpanel_paydates.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jpanel_paydatesLayout = new javax.swing.GroupLayout(jpanel_paydates);
        jpanel_paydates.setLayout(jpanel_paydatesLayout);
        jpanel_paydatesLayout.setHorizontalGroup(
            jpanel_paydatesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 648, Short.MAX_VALUE)
        );
        jpanel_paydatesLayout.setVerticalGroup(
            jpanel_paydatesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 326, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(jpanel_paydates);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(146, 159, -1, 280));

        btn_reminder.setBackground(new java.awt.Color(51, 153, 0));
        btn_reminder.setForeground(new java.awt.Color(255, 255, 255));
        btn_reminder.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/reminder.png"))); // NOI18N
        btn_reminder.setText("Send reminder");
        jPanel1.add(btn_reminder, new org.netbeans.lib.awtextra.AbsoluteConstraints(396, 470, 140, 30));
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(796, 103, -1, -1));

        cmbDateFilter.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        cmbDateFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbDateFilterActionPerformed(evt);
            }
        });
        jPanel1.add(cmbDateFilter, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 110, 220, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btn_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchActionPerformed
        String parentName = txtsearch_name.getText().trim();
        loadData(parentName, loggedInDriver);
    }//GEN-LAST:event_btn_searchActionPerformed

    private void cmbDateFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbDateFilterActionPerformed

    }//GEN-LAST:event_cmbDateFilterActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_reminder;
    private javax.swing.JButton btn_search;
    private javax.swing.JComboBox<String> cmbDateFilter;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel jpanel_paydates;
    private javax.swing.JTextField txtsearch_name;
    // End of variables declaration//GEN-END:variables
}
