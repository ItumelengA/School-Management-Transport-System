
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.*;

public class PendingDocuments extends javax.swing.JPanel {

    private int selectedDriverId = -1;
    private JPanel selectedCard = null;

    public PendingDocuments() {
        initComponents();

        loadPendingDrivers("");

    }

    private void loadPendingDrivers(String keyword) {
        cardPanel.removeAll();

        // Create a wrapper panel with BoxLayout for proper scrolling
        JPanel wrapperPanel = new JPanel();
        wrapperPanel.setLayout(new BoxLayout(wrapperPanel, BoxLayout.Y_AXIS));
        wrapperPanel.setBackground(new Color(240, 240, 240));
        wrapperPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        try (Connection conn = DatabaseHelper.getConnection()) {
            String sql = "SELECT t.Transport_ID, d.Driver_ID, d.Name, d.Surname, d.Phone_number, d.School_name, "
                    + "t.Vehicle_make, t.Vehicle_model, t.Vehicle_registration, t.Status "
                    + "FROM Transport t "
                    + "JOIN driver_registrations d ON t.Driver_ID = d.Driver_ID "
                    + "WHERE t.Status = 'Pending'";

            if (keyword != null && !keyword.isEmpty()) {
                sql += " AND (d.Name LIKE ? OR d.Surname LIKE ? OR t.Vehicle_registration LIKE ?)";
            }

            PreparedStatement ps = conn.prepareStatement(sql);
            if (keyword != null && !keyword.isEmpty()) {
                ps.setString(1, "%" + keyword + "%");
                ps.setString(2, "%" + keyword + "%");
                ps.setString(3, "%" + keyword + "%");
            }

            ResultSet rs = ps.executeQuery();
            boolean hasResults = false;

            while (rs.next()) {
                hasResults = true;
                int driverId = rs.getInt("Driver_ID");
                String name = rs.getString("Name");
                String surname = rs.getString("Surname");
                String phone = rs.getString("Phone_number");
                String school = rs.getString("School_name");
                String vehicleMake = rs.getString("Vehicle_make");
                String vehicleModel = rs.getString("Vehicle_model");
                String regNo = rs.getString("Vehicle_registration");
                String status = rs.getString("Status");

                JPanel card = createCard(name, surname, phone, school, vehicleMake, vehicleModel, regNo, status, driverId);

                // Set maximum size to prevent horizontal stretching
                card.setMaximumSize(new Dimension(Integer.MAX_VALUE, card.getPreferredSize().height));

                wrapperPanel.add(card);
                wrapperPanel.add(Box.createVerticalStrut(15)); // Space between cards
            }

            if (!hasResults) {
                JLabel noData = new JLabel("No pending drivers found.", SwingConstants.CENTER);
                noData.setFont(new Font("Segoe UI", Font.ITALIC, 16));
                noData.setForeground(Color.GRAY);
                noData.setAlignmentX(Component.CENTER_ALIGNMENT);

                wrapperPanel.add(Box.createVerticalGlue());
                wrapperPanel.add(noData);
                wrapperPanel.add(Box.createVerticalGlue());
            } else {
                // Add glue at the end to push cards to top
                wrapperPanel.add(Box.createVerticalGlue());
            }

            // Set the wrapper panel to cardPanel with BorderLayout
            cardPanel.setLayout(new BorderLayout());
            cardPanel.add(wrapperPanel, BorderLayout.NORTH);

            cardPanel.revalidate();
            cardPanel.repaint();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading pending drivers: " + e.getMessage());
        }
    }

    private JPanel createCard(String name, String surname, String phone, String school,
            String vehicleMake, String vehicleModel, String regNo,
            String status, int driverId) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        card.setBackground(Color.WHITE);

        // Create labels with the same information as before
        JLabel nameLabel = new JLabel("Fullname: " + name + " " + surname);
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        nameLabel.setForeground(new Color(51, 51, 51));
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel phoneLabel = new JLabel("Phone: " + phone);
        phoneLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        phoneLabel.setForeground(new Color(102, 102, 102));
        phoneLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel schoolLabel = new JLabel("School: " + school);
        schoolLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        schoolLabel.setForeground(new Color(102, 102, 102));
        schoolLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel vehicleLabel = new JLabel("Vehicle: " + vehicleMake + " " + vehicleModel);
        vehicleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        vehicleLabel.setForeground(new Color(102, 102, 102));
        vehicleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel regLabel = new JLabel("Registration: " + regNo);
        regLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        regLabel.setForeground(new Color(102, 102, 102));
        regLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Status label with badge style
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 5));
        statusPanel.setBackground(Color.WHITE);
        statusPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel statusLabel = new JLabel(status);
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 11));
        statusLabel.setForeground(new Color(255, 140, 0));
        statusLabel.setBorder(BorderFactory.createEmptyBorder(5, 12, 5, 12));
        statusLabel.setOpaque(true);
        statusLabel.setBackground(new Color(255, 245, 230));

        statusPanel.add(statusLabel);

        // Add all components to card
        card.add(nameLabel);
        card.add(Box.createVerticalStrut(8));
        card.add(phoneLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(schoolLabel);
        card.add(Box.createVerticalStrut(8));
        card.add(vehicleLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(regLabel);
        card.add(Box.createVerticalStrut(8));
        card.add(statusPanel);

        // Mouse listener for selection
        card.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Reset previous selection
                if (selectedCard != null) {
                    selectedCard.setBackground(Color.WHITE);
                    selectedCard.setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(new Color(180, 180, 180), 1),
                            BorderFactory.createEmptyBorder(15, 15, 15, 15)
                    ));
                }

                // Highlight selected card
                card.setBackground(new Color(230, 245, 255));
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(0, 102, 204), 2),
                        BorderFactory.createEmptyBorder(14, 14, 14, 14)
                ));

                selectedCard = card;
                selectedDriverId = driverId;
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                if (selectedCard != card) {
                    card.setCursor(new Cursor(Cursor.HAND_CURSOR));
                }
            }
        });

        return card;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtSearch = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        cardPanel = new javax.swing.JPanel();
        btnApprove = new javax.swing.JButton();
        btnViewFile = new javax.swing.JButton();
        btnReject = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtSearch.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        add(txtSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 390, 30));

        btnSearch.setBackground(new java.awt.Color(0, 51, 102));
        btnSearch.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/search_2.png"))); // NOI18N
        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });
        add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 40, 100, 30));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        cardPanel.setBackground(new java.awt.Color(255, 255, 255));
        cardPanel.setAutoscrolls(true);
        cardPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cardPanel.setPreferredSize(new java.awt.Dimension(650, 220));
        cardPanel.setLayout(new javax.swing.BoxLayout(cardPanel, javax.swing.BoxLayout.LINE_AXIS));
        jScrollPane1.setViewportView(cardPanel);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 73, 990, 380));

        btnApprove.setBackground(new java.awt.Color(0, 153, 0));
        btnApprove.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnApprove.setForeground(new java.awt.Color(255, 255, 255));
        btnApprove.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/approve.png"))); // NOI18N
        btnApprove.setText("Approve");
        btnApprove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnApproveActionPerformed(evt);
            }
        });
        add(btnApprove, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 473, 122, -1));

        btnViewFile.setBackground(new java.awt.Color(0, 51, 102));
        btnViewFile.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnViewFile.setForeground(new java.awt.Color(255, 255, 255));
        btnViewFile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/revi.png"))); // NOI18N
        btnViewFile.setText("View File");
        btnViewFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewFileActionPerformed(evt);
            }
        });
        add(btnViewFile, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 470, 122, -1));

        btnReject.setBackground(new java.awt.Color(255, 0, 0));
        btnReject.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnReject.setForeground(new java.awt.Color(255, 255, 255));
        btnReject.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/rejected.png"))); // NOI18N
        btnReject.setText("Reject");
        btnReject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRejectActionPerformed(evt);
            }
        });
        add(btnReject, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 470, 120, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed

        String keyword = txtSearch.getText().trim();
        loadPendingDrivers(keyword);

    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnRejectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRejectActionPerformed
        if (selectedDriverId == -1) {
            JOptionPane.showMessageDialog(this, "Please select a driver from the list.");
            return;
        }

        // Create a custom dialog for rejection reason
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel label = new JLabel("Please provide a reason for rejection:");
        label.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JTextArea reasonArea = new JTextArea(5, 30);
        reasonArea.setLineWrap(true);
        reasonArea.setWrapStyleWord(true);
        reasonArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        reasonArea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));

        JScrollPane scrollPane = new JScrollPane(reasonArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        panel.add(label, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        int result = JOptionPane.showConfirmDialog(
                this,
                panel,
                "Rejection Reason",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            String rejectionReason = reasonArea.getText().trim();

            if (rejectionReason.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please provide a reason for rejection.",
                        "Reason Required",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            try (Connection conn = DatabaseHelper.getConnection()) {
                String sql = "UPDATE Transport SET Status = 'Rejected', Rejected_reason = ? WHERE Driver_ID = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, rejectionReason);
                ps.setInt(2, selectedDriverId);
                int updated = ps.executeUpdate();

                if (updated > 0) {
                    JOptionPane.showMessageDialog(this, "Driver Rejected Successfully.");
                    loadPendingDrivers("");
                    selectedDriverId = -1;
                } else {
                    JOptionPane.showMessageDialog(this, "Unable to reject. Please try again.");
                }

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
            }

        }
    }//GEN-LAST:event_btnRejectActionPerformed

    private void btnViewFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewFileActionPerformed
        if (selectedDriverId == -1) {
            JOptionPane.showMessageDialog(this, "Please select a driver first.");
            return;
        }

        try (Connection conn = DatabaseHelper.getConnection()) {
            String sql = "SELECT pdf_name, License_pdf FROM Transport WHERE Driver_ID = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, selectedDriverId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String pdfName = rs.getString("pdf_name");
                Blob pdfBlob = rs.getBlob("License_pdf");

                File pdfFile = new File(System.getProperty("java.io.tmpdir"), pdfName);
                try (InputStream in = pdfBlob.getBinaryStream(); FileOutputStream out = new FileOutputStream(pdfFile)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = in.read(buffer)) != -1) {
                        out.write(buffer, 0, bytesRead);
                    }
                }

                Desktop.getDesktop().open(pdfFile);
            } else {
                JOptionPane.showMessageDialog(this, "File not found for selected driver.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error opening file: " + e.getMessage());
        }
    }//GEN-LAST:event_btnViewFileActionPerformed

    private void btnApproveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnApproveActionPerformed
        if (selectedDriverId == -1) {
            JOptionPane.showMessageDialog(this, "Please select a driver from the list.");
            return;
        }

        try (Connection conn = DatabaseHelper.getConnection()) {
            String sql = "UPDATE Transport SET Status = 'Approved' WHERE Driver_ID = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, selectedDriverId);
            int updated = ps.executeUpdate();

            if (updated > 0) {
                JOptionPane.showMessageDialog(this, "Driver Approved Successfully!");
                loadPendingDrivers("");
                selectedDriverId = -1;
            } else {
                JOptionPane.showMessageDialog(this, "Unable to approve. Please try again.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }
    }//GEN-LAST:event_btnApproveActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnApprove;
    private javax.swing.JButton btnReject;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnViewFile;
    private javax.swing.JPanel cardPanel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
