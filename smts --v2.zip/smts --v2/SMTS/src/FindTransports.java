
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class FindTransports extends javax.swing.JPanel {
    public FindTransports() {
        initComponents();
        loadData();
    }

    private void loadData(String schoolFilter) {
        try (Connection con = DatabaseHelper.getConnection()) {
            String query = "SELECT school_name, driver_name, available_time, price, available_seats "
                    + "FROM TransportSchedule";

            if (schoolFilter != null && !schoolFilter.trim().isEmpty()) {
                query += " WHERE school_name LIKE ?";
            }

            PreparedStatement stmt = con.prepareStatement(query);

            if (schoolFilter != null && !schoolFilter.trim().isEmpty()) {
                stmt.setString(1, "%" + schoolFilter.trim() + "%"); // partial match
            }

            ResultSet rs = stmt.executeQuery();

            // Clear panel
            jPanel2.removeAll();
            jPanel2.setLayout(new GridLayout(0, 1, 15, 15));
            jPanel2.setBackground(new Color(240, 240, 240));
            jPanel2.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            while (rs.next()) {
                JPanel card = new JPanel() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        Graphics2D g2 = (Graphics2D) g;
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                        g2.setColor(new Color(200, 200, 200, 100)); // shadow
                        g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);

                        g2.setColor(Color.WHITE); // white background
                        g2.fillRoundRect(0, 0, getWidth() - 10, getHeight() - 10, 20, 20);
                    }
                };
                card.setLayout(new BorderLayout(10, 10));
                card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
                card.setOpaque(false);
                card.setPreferredSize(new Dimension(600, 120));

                JPanel contentPanel = new JPanel(new GridLayout(2, 2, 10, 10));
                contentPanel.setOpaque(false);

                JLabel lblSchool = new JLabel("School: " + rs.getString("school_name"));
                lblSchool.setFont(new Font("Segoe UI", Font.BOLD, 14));
                lblSchool.setForeground(new Color(70, 130, 180));

                JLabel lblDriver = new JLabel("Driver: " + rs.getString("driver_name"));
                lblDriver.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                lblDriver.setForeground(new Color(51, 51, 51));

                JLabel lblTime = new JLabel("Time: " + rs.getTime("available_time").toString());
                lblTime.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                lblTime.setForeground(new Color(100, 100, 100));

                JLabel lblPrice = new JLabel("Price: R" + String.format("%.2f", rs.getDouble("price")));
                lblPrice.setFont(new Font("Segoe UI", Font.BOLD, 12));
                lblPrice.setForeground(new Color(0, 100, 0));

                contentPanel.add(lblSchool);
                contentPanel.add(lblDriver);
                contentPanel.add(lblTime);
                contentPanel.add(lblPrice);

                JPanel rightPanel = new JPanel();
                rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
                rightPanel.setOpaque(false);
                rightPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));

                int seats = rs.getInt("available_seats");
                JLabel lblSeats = new JLabel("Seats: " + seats);
                lblSeats.setFont(new Font("Segoe UI", Font.BOLD, 14));
                lblSeats.setForeground(seats > 0 ? new Color(0, 100, 0) : new Color(200, 0, 0));
                lblSeats.setAlignmentX(Component.CENTER_ALIGNMENT);
                lblSeats.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

                JButton arrangeBtn = new JButton("Arrange");
                styleButton(arrangeBtn, new Color(0, 153, 0));
                arrangeBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
                arrangeBtn.setMaximumSize(new Dimension(120, 35));

                String school = rs.getString("school_name");
                String driver = rs.getString("driver_name");
                String time = rs.getTime("available_time").toString();
                double price = rs.getDouble("price");
                int availableSeats = seats;

                arrangeBtn.addActionListener(e -> {
                    String message = String.format(
                            "Arranging transport for:\n"
                            + "School: %s\nDriver: %s\nTime: %s\nPrice: R%.2f\nSeats Available: %d",
                            school, driver, time, price, availableSeats
                    );
                    JOptionPane.showMessageDialog(this, message, "Arrange Transport", JOptionPane.INFORMATION_MESSAGE);
                });

                rightPanel.add(lblSeats);
                rightPanel.add(arrangeBtn);

                card.add(contentPanel, BorderLayout.CENTER);
                card.add(rightPanel, BorderLayout.EAST);

                jPanel2.add(card);
            }

            jPanel2.revalidate();
            jPanel2.repaint();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

// 🔹 Default load (show all data)
    private void loadData() {
        loadData(null);
    }
// Load data from DB and create cards

    // Style button method
    private void styleButton(JButton button, Color bgColor) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        scrollpane = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        btnsearch = new javax.swing.JButton();
        txtSearchbar = new javax.swing.JTextField();

        setBackground(new java.awt.Color(255, 255, 255));

        scrollpane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollpane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 680, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 366, Short.MAX_VALUE)
        );

        scrollpane.setViewportView(jPanel2);

        btnsearch.setBackground(new java.awt.Color(0, 102, 204));
        btnsearch.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnsearch.setForeground(new java.awt.Color(255, 255, 255));
        btnsearch.setText("Search");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 817, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txtSearchbar, javax.swing.GroupLayout.PREFERRED_SIZE, 382, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(374, 374, 374)
                            .addComponent(btnsearch))
                        .addComponent(scrollpane, javax.swing.GroupLayout.PREFERRED_SIZE, 680, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 522, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(1, 1, 1)
                            .addComponent(txtSearchbar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(btnsearch))
                    .addGap(6, 6, 6)
                    .addComponent(scrollpane, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
        String searchText = txtSearchbar.getText();
        loadData(searchText);
    }//GEN-LAST:event_btnsearchActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnsearch;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane scrollpane;
    private javax.swing.JTextField txtSearchbar;
    // End of variables declaration//GEN-END:variables
}
