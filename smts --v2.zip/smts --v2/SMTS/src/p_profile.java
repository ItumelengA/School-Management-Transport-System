
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class p_profile extends javax.swing.JPanel {

    private Parent loggedInParent;
    private User loggedInUser;

    public p_profile() {
        initComponents();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        lblName = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        lblEmail = new javax.swing.JLabel();
        lblPhoneNumber = new javax.swing.JLabel();
        lblEmergencyNumber = new javax.swing.JLabel();
        lblSurname = new javax.swing.JLabel();
        btnEdit = new javax.swing.JButton();
        btn_delete_acc = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        lblRelationship = new javax.swing.JLabel();
        txtPassword = new javax.swing.JPasswordField();
        jPanel8 = new javax.swing.JPanel();
        btn_Cancel_arrangement = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        lblChild_Name = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        lblChild_MidName = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        lbl_child_surname = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        lblDOB = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        lblAge = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        lblSchool = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        lblPickup = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        lblDropoff = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        lblMedical = new javax.swing.JTextArea();
        jLabel33 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel34 = new javax.swing.JLabel();
        lblDriverName = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        btn_Edit_Child = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(249, 249, 249));
        jPanel1.setMaximumSize(new java.awt.Dimension(1000, 510));
        jPanel1.setMinimumSize(new java.awt.Dimension(1000, 510));
        jPanel1.setPreferredSize(new java.awt.Dimension(1000, 510));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 102));

        jLabel21.setBackground(new java.awt.Color(255, 255, 255));
        jLabel21.setFont(new java.awt.Font("Segoe UI Symbol", 0, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("School Ride | © 2025 | Follow us on Twitter @SchoolRideApp");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(379, 379, 379)
                .addComponent(jLabel21)
                .addContainerGap(494, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel21)
                .addGap(16, 16, 16))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 630, 1360, 50));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Parent Overview", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Semibold", 0, 14))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("Name:");

        lblName.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblName.setText("---");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 102, 102));
        jLabel5.setText("Surname:");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(102, 102, 102));
        jLabel6.setText("Email:");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(102, 102, 102));
        jLabel7.setText("Phone number:");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(102, 102, 102));
        jLabel8.setText("Emergency phone number:");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(102, 102, 102));
        jLabel9.setText("Password:");

        lblEmail.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblEmail.setText("---");

        lblPhoneNumber.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblPhoneNumber.setText("---");

        lblEmergencyNumber.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblEmergencyNumber.setText("---");

        lblSurname.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblSurname.setText("---");

        btnEdit.setBackground(new java.awt.Color(0, 102, 153));
        btnEdit.setForeground(new java.awt.Color(255, 255, 255));
        btnEdit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/edit_icon.png"))); // NOI18N
        btnEdit.setText("Edit");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btn_delete_acc.setBackground(new java.awt.Color(51, 153, 0));
        btn_delete_acc.setForeground(new java.awt.Color(255, 255, 255));
        btn_delete_acc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/delete.png"))); // NOI18N
        btn_delete_acc.setText("Delete Account");
        btn_delete_acc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_delete_accActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("Relationship:");

        lblRelationship.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblRelationship.setText("--");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblEmergencyNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblRelationship, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)
                        .addComponent(btn_delete_acc))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblName, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(lblSurname, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblPhoneNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(lblName))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(lblSurname))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(lblEmail))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(lblPhoneNumber))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(lblEmergencyNumber))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(lblRelationship))
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addGap(29, 29, 29)
                .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnEdit)
                    .addComponent(btn_delete_acc)))
        );

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, 320, 440));

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Child Information"));

        btn_Cancel_arrangement.setBackground(new java.awt.Color(51, 153, 0));
        btn_Cancel_arrangement.setForeground(new java.awt.Color(255, 255, 255));
        btn_Cancel_arrangement.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/cancel.png"))); // NOI18N
        btn_Cancel_arrangement.setText("Cancel Arrangement");
        btn_Cancel_arrangement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Cancel_arrangementActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(102, 102, 102));
        jLabel15.setText("Name");

        lblChild_Name.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblChild_Name.setText("---");

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(102, 102, 102));
        jLabel18.setText("Middle Name");

        lblChild_MidName.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblChild_MidName.setText("---");
        lblChild_MidName.setToolTipText("---");

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(102, 102, 102));
        jLabel20.setText("Surname");

        lbl_child_surname.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lbl_child_surname.setText("---");

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(102, 102, 102));
        jLabel23.setText("Date of birth");

        lblDOB.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblDOB.setText("---");

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(102, 102, 102));
        jLabel25.setText("Age");

        lblAge.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblAge.setText("---");

        jLabel27.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(102, 102, 102));
        jLabel27.setText("School name");

        lblSchool.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblSchool.setText("---");

        jLabel29.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(102, 102, 102));
        jLabel29.setText("Pickup location");

        lblPickup.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblPickup.setText("---");

        jLabel31.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(102, 102, 102));
        jLabel31.setText("Dropoff location");

        lblDropoff.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblDropoff.setText("---");

        lblMedical.setColumns(20);
        lblMedical.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        lblMedical.setRows(5);
        jScrollPane2.setViewportView(lblMedical);

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(102, 102, 102));
        jLabel33.setText("Medical condition");

        jLabel34.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(102, 102, 102));
        jLabel34.setText("Driver assigned:");

        lblDriverName.setFont(new java.awt.Font("Lucida Sans", 1, 12)); // NOI18N
        lblDriverName.setText("---");

        btn_Edit_Child.setBackground(new java.awt.Color(0, 102, 153));
        btn_Edit_Child.setForeground(new java.awt.Color(255, 255, 255));
        btn_Edit_Child.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/edit_icon.png"))); // NOI18N
        btn_Edit_Child.setText("Edit details");
        btn_Edit_Child.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Edit_ChildActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel33)
                            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jSeparator4)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel8Layout.createSequentialGroup()
                                    .addComponent(jLabel34)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(lblDriverName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addComponent(jSeparator3)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(130, 130, 130))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblChild_Name, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel23)
                                        .addComponent(lblChild_MidName, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel8Layout.createSequentialGroup()
                                            .addGap(1, 1, 1)
                                            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel15)
                                                .addComponent(jLabel18)))
                                        .addComponent(jLabel20)
                                        .addComponent(lbl_child_surname, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(38, 38, 38)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblAge, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel25)
                                    .addComponent(jLabel27)
                                    .addComponent(jLabel29)
                                    .addComponent(lblSchool, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(btn_Edit_Child)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_Cancel_arrangement))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                                .addComponent(lblDOB, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(38, 38, 38)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel31)
                                    .addComponent(lblPickup, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblDropoff, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(60, 60, 60))))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jLabel25))
                .addGap(2, 2, 2)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblChild_Name)
                    .addComponent(lblAge))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(jLabel27))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblChild_MidName)
                    .addComponent(lblSchool))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(jLabel29))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_child_surname, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPickup))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23)
                    .addComponent(jLabel31, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDOB)
                    .addComponent(lblDropoff))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel33)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(lblDriverName))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Cancel_arrangement)
                    .addComponent(btn_Edit_Child))
                .addGap(34, 34, 34))
        );

        jPanel1.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 65, 360, 440));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1112, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 572, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btn_delete_accActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_delete_accActionPerformed
        if (loggedInParent == null) {
            JOptionPane.showMessageDialog(null, "No parent is logged in.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(null,
                "Are you sure you want to delete your account? "
                + "\n This action cannot be undone.",
                "Confirm Account Deletion",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String deleteParentSQL = "DELETE FROM Parent WHERE Parent_ID = ?";

        try (Connection conn = DatabaseHelper.getConnection(); PreparedStatement stmt = conn.prepareStatement(deleteParentSQL)) {

            stmt.setInt(1, loggedInParent.getParentId());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Account deleted successfully.");

                Login direct_login = new Login();
                direct_login.setVisible(true);
                direct_login.dispose();

            } else {
                JOptionPane.showMessageDialog(null, "Account deletion failed.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error deleting account: " + e.getMessage());
        }
    }//GEN-LAST:event_btn_delete_accActionPerformed

    private void btn_Edit_ChildActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Edit_ChildActionPerformed
        if (loggedInParent == null) {
            JOptionPane.showMessageDialog(null, "No parent is logged in.");
            return;
        }

        // Create text fields and prefill them with existing values from labels
        JTextField txtName = new JTextField(lblChild_Name.getText());
        JTextField txtMidName = new JTextField(lblChild_MidName.getText());
        JTextField txtSurname = new JTextField(lbl_child_surname.getText());
        JTextField txtSchool = new JTextField(lblSchool.getText());
        JTextField txtPickup = new JTextField(lblPickup.getText());
        JTextField txtDropoff = new JTextField(lblDropoff.getText());

        // JTextArea for Medical Condition
        JTextArea txtMedical = new JTextArea(lblMedical.getText(), 5, 20);
        txtMedical.setLineWrap(true);
        txtMedical.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(txtMedical);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        // Create form layout for JOptionPane
        Object[] message = {
            "Name:", txtName,
            "Middle Name:", txtMidName,
            "Surname:", txtSurname,
            "School Name:", txtSchool,
            "Pickup Location:", txtPickup,
            "Dropoff Location:", txtDropoff,
            "Medical Condition:", scrollPane
        };

        // Show dialog
        int option = JOptionPane.showConfirmDialog(
                null,
                message,
                "Edit Learner Information",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (option == JOptionPane.OK_OPTION) {
            try (Connection conn = DatabaseHelper.getConnection()) {

                String sql = "UPDATE Learner SET Name = ?, MidName = ?, Surname = ?, ScholName = ?, "
                        + "Pickup_Location = ?, Dropoff_Location = ?, MedicalCondition = ? "
                        + "WHERE Parent_ID = ?";

                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, txtName.getText());
                    stmt.setString(2, txtMidName.getText());
                    stmt.setString(3, txtSurname.getText());
                    stmt.setString(4, txtSchool.getText());
                    stmt.setString(5, txtPickup.getText());
                    stmt.setString(6, txtDropoff.getText());
                    stmt.setString(7, txtMedical.getText());
                    stmt.setInt(8, loggedInParent.getParentId());

                    int rows = stmt.executeUpdate();
                    if (rows > 0) {
                        JOptionPane.showMessageDialog(null, "Learner information updated successfully!");

                        // Refresh displayed info
                        setLoggedInParent(loggedInParent);
                    } else {
                        JOptionPane.showMessageDialog(null, "No learner record found to update.");
                    }
                }

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating learner info: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_btn_Edit_ChildActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
        if (loggedInParent == null) {
            JOptionPane.showMessageDialog(null, "No parent is logged in.");
            return;
        }

        // Editable fields for parent info
        JTextField txtName = new JTextField(loggedInParent.getName());
        JTextField txtSurname = new JTextField(loggedInParent.getSurname());
        JTextField txtPhone = new JTextField(loggedInParent.getPhone_number());
        JTextField txtEmergency = new JTextField(loggedInParent.getEmergency_number());

        // Relationship combo box
        String[] relationships = {"Mother", "Father", "Guardian"};
        JComboBox<String> cbRelationship = new JComboBox<>(relationships);
        cbRelationship.setSelectedItem(loggedInParent.getRelationship());

        // Email and password (from Login table)
        JTextField txtEmail = new JTextField(loggedInUser.getEmail());
        JPasswordField txtPassword = new JPasswordField(loggedInUser.getPassword());

        // Build the form layout
        Object[] message = {
            "Name:", txtName,
            "Surname:", txtSurname,
            "Phone Number:", txtPhone,
            "Emergency Contact:", txtEmergency,
            "Relationship:", cbRelationship,
            "Email:", txtEmail,
            "Password:", txtPassword
        };

        int option = JOptionPane.showConfirmDialog(
                null,
                message,
                "Edit Parent Information",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (option == JOptionPane.OK_OPTION) {
            try (Connection conn = DatabaseHelper.getConnection()) {

                // ✅ Update Parent table (without Email)
                String sqlParent = "UPDATE Parent SET Name = ?, Surname = ?, "
                        + "Phone_number = ?, Emergency_number = ?, Relationship = ? "
                        + "WHERE Parent_ID = ?";

                try (PreparedStatement stmtParent = conn.prepareStatement(sqlParent)) {
                    stmtParent.setString(1, txtName.getText());
                    stmtParent.setString(2, txtSurname.getText());
                    stmtParent.setString(3, txtPhone.getText());
                    stmtParent.setString(4, txtEmergency.getText());
                    stmtParent.setString(5, cbRelationship.getSelectedItem().toString());
                    stmtParent.setInt(6, loggedInParent.getParentId());
                    stmtParent.executeUpdate();
                }

                // ✅ Update Login table (Email & Password)
                String sqlLogin = "UPDATE Login SET Email = ?, Password = ? WHERE Login_ID = ?";
                try (PreparedStatement stmtLogin = conn.prepareStatement(sqlLogin)) {
                    stmtLogin.setString(1, txtEmail.getText());
                    stmtLogin.setString(2, new String(txtPassword.getPassword()));
                    stmtLogin.setInt(3, loggedInParent.getLoginId());
                    stmtLogin.executeUpdate();
                }

                JOptionPane.showMessageDialog(null, "Parent profile updated successfully!");

                // Update parent and login objects in memory
                loggedInParent.setName(txtName.getText());
                loggedInParent.setSurname(txtSurname.getText());
                loggedInParent.setPhone_number(txtPhone.getText());
                loggedInParent.setEmergency_number(txtEmergency.getText());
                loggedInParent.setRelationship(cbRelationship.getSelectedItem().toString());

                loggedInUser.setEmail(txtEmail.getText());
                loggedInUser.setPassword(new String(txtPassword.getPassword()));

                // Refresh labels
                updateProfileInfo();

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating parent info: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnEditActionPerformed

    private void btn_Cancel_arrangementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Cancel_arrangementActionPerformed
        if (loggedInParent == null) {
            JOptionPane.showMessageDialog(null, "No parent is logged in.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(null,
                "Are you sure you want to cancel this arrangement?",
                "Confirm Cancellation",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        boolean success = DatabaseHelper.cancelArrangement(loggedInParent.getParentId());

        if (success) {
            JOptionPane.showMessageDialog(null, "Arrangement cancelled successfully!");
            // Clear learner info from labels
            lblDriverName.setText("No arrangement yet");
            // Optionally refresh learner info if needed
        } else {
            JOptionPane.showMessageDialog(null, "No arrangement found to cancel.");
        }

    }//GEN-LAST:event_btn_Cancel_arrangementActionPerformed

    public void setLoggedInParent(Parent parent) {
        this.loggedInParent = parent;
        updateProfileInfo();

        String sql = "SELECT l.Name AS LearnerName, l.MidName, l.Surname AS LearnerSurname, l.DateOfBirth, l.Age, "
                + "l.ScholName, l.Pickup_Location, l.Dropoff_Location, l.MedicalCondition, "
                + "a.Driver_Name, a.Driver_Surname "
                + "FROM Learner l "
                + "LEFT JOIN Arrangement a ON l.Learner_ID = a.Learner_ID " // ✅ LEFT JOIN ensures learner shows even if no arrangement
                + "WHERE l.Parent_ID = ?";

        try (Connection conn = DatabaseHelper.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, loggedInParent.getParentId());
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                lblChild_Name.setText(rs.getString("LearnerName"));
                lblChild_MidName.setText(rs.getString("MidName"));
                lbl_child_surname.setText(rs.getString("LearnerSurname"));
                lblDOB.setText(rs.getDate("DateOfBirth").toString());
                lblAge.setText(rs.getString("Age"));
                lblSchool.setText(rs.getString("ScholName"));
                lblPickup.setText(rs.getString("Pickup_Location"));
                lblDropoff.setText(rs.getString("Dropoff_Location"));
                lblMedical.setText(rs.getString("MedicalCondition"));

                String driverName = rs.getString("Driver_Name");
                String driverSurname = rs.getString("Driver_Surname");

                if (driverName != null && driverSurname != null) {
                    lblDriverName.setText(driverName + " " + driverSurname);
                } else {
                    lblDriverName.setText("No arrangement yet");
                }

            } else {

                JOptionPane.showMessageDialog(null, "No learner registered for this parent.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error retrieving learner data: " + e.getMessage());
        }
    }

    public void setLoggedInUser(User user) {
        this.loggedInUser = user;
        updateProfileInfo();

    }

    private void updateProfileInfo() {
        if (loggedInParent != null) {
            lblName.setText(loggedInParent.getName());
            lblSurname.setText(loggedInParent.getSurname());

            if (loggedInUser != null) {
                lblEmail.setText(loggedInUser.getEmail());
            } else {
                lblEmail.setText("***");
            }
            lblEmail.setText(loggedInParent.getEmail());
            lblPhoneNumber.setText(loggedInParent.getPhone_number());
            lblEmergencyNumber.setText(loggedInParent.getEmergency_number());
            lblRelationship.setText(loggedInParent.getRelationship());

            if (loggedInUser != null) {
                txtPassword.setText(loggedInUser.getPassword());
            } else {
                txtPassword.setText("***");
            }
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btn_Cancel_arrangement;
    private javax.swing.JButton btn_Edit_Child;
    private javax.swing.JButton btn_delete_acc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JLabel lblAge;
    private javax.swing.JLabel lblChild_MidName;
    private javax.swing.JLabel lblChild_Name;
    private javax.swing.JLabel lblDOB;
    private javax.swing.JLabel lblDriverName;
    private javax.swing.JLabel lblDropoff;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblEmergencyNumber;
    private javax.swing.JTextArea lblMedical;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblPhoneNumber;
    private javax.swing.JLabel lblPickup;
    private javax.swing.JLabel lblRelationship;
    private javax.swing.JLabel lblSchool;
    private javax.swing.JLabel lblSurname;
    private javax.swing.JLabel lbl_child_surname;
    private javax.swing.JPasswordField txtPassword;
    // End of variables declaration//GEN-END:variables
}
