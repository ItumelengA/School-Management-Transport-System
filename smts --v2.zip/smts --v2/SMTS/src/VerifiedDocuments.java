
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.BorderFactory;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class VerifiedDocuments extends javax.swing.JPanel {

    private JPanel selectedCard = null;
    private String selectedDriverName = null;
    private int selectedDriverId = -1;

    public VerifiedDocuments() {
        initComponents();

        loadVerifiedDocuments();

    }

    private void loadVerifiedDocumentsWithSearch(String searchText) {
        try (Connection con = DatabaseHelper.getConnection()) {
            String sql = "SELECT t.Transport_ID, d.Driver_ID, d.Name, d.Surname, "
                    + "t.pdf_name,t.License_pdf, t.License_number, t.Vehicle_make, t.Vehicle_model, t.Vehicle_registration, t.Status "
                    + "FROM Transport t "
                    + "JOIN driver_registrations d ON t.Driver_ID = d.Driver_ID "
                    + "WHERE t.Status = 'Approved'";

            if (searchText != null && !searchText.trim().isEmpty()) {
                sql += " AND (d.Name LIKE ? OR d.Surname LIKE ?)";
            }

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                if (searchText != null && !searchText.trim().isEmpty()) {
                    String sText = "%" + searchText.trim() + "%";
                    ps.setString(1, sText);
                    ps.setString(2, sText);
                }

                try (ResultSet rs = ps.executeQuery()) {
                    buildCards(rs);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void loadVerifiedDocuments() {
        try (Connection con = DatabaseHelper.getConnection()) {
            String sql = "SELECT t.Transport_ID, d.Driver_ID, d.Name, d.Surname, "
                    + "t.pdf_name,t.License_pdf, t.License_number, t.Vehicle_make, t.Vehicle_model, t.Vehicle_registration, t.Status "
                    + "FROM Transport t "
                    + "JOIN driver_registrations d ON t.Driver_ID = d.Driver_ID "
                    + "WHERE t.Status = 'Approved'";

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                try (ResultSet rs = ps.executeQuery()) {
                    buildCards(rs);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    private void buildCards(ResultSet rs) throws Exception {
        jPanel1.removeAll();
        jPanel1.setLayout(new GridLayout(0, 1, 15, 15));
        jPanel1.setBackground(new Color(240, 240, 240));
        jPanel1.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        boolean hasResults = false;

        while (rs.next()) {
            hasResults = true;

            int driverId = rs.getInt("Driver_ID");
            String name = rs.getString("Name");
            String surname = rs.getString("Surname");
            String vehicleMake = rs.getString("Vehicle_make");
            String vehicleModel = rs.getString("Vehicle_model");
            String licenseNo = rs.getString("License_number");
            String pdfname = rs.getString("pdf_name");
            String vehicleReg = rs.getString("Vehicle_registration");

            JPanel card = new JPanel(new GridLayout(0, 1, 5, 5));
            card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(180, 180, 180), 1),
                    BorderFactory.createEmptyBorder(10, 10, 10, 10)
            ));
            card.setBackground(Color.WHITE);

            card.add(new JLabel("Driver: " + name + " " + surname));
            card.add(new JLabel("License PDF Name: " + pdfname));
            card.add(new JLabel("License No: " + (licenseNo != null ? licenseNo : "N/A")));
            card.add(new JLabel("Vehicle Make: " + vehicleMake));
            card.add(new JLabel("Vehicle Model: " + vehicleModel));
            card.add(new JLabel("Vehicle Registration: " + vehicleReg));

            card.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseClicked(java.awt.event.MouseEvent e) {
                    // Set the selected driver ID
                    selectedDriverId = driverId;
                    selectedDriverName = name + " " + surname;

                    // Reset previous selection
                    if (selectedCard != null) {
                        selectedCard.setBackground(Color.WHITE);
                        selectedCard.setBorder(BorderFactory.createCompoundBorder(
                                BorderFactory.createLineBorder(new Color(180, 180, 180), 1),
                                BorderFactory.createEmptyBorder(10, 10, 10, 10)
                        ));
                    }

                    // Highlight selected card
                    card.setBackground(new Color(200, 230, 255));
                    card.setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(new Color(0, 51, 102), 2),
                            BorderFactory.createEmptyBorder(9, 9, 9, 9)
                    ));
                    selectedCard = card;
                }
            });

            jPanel1.add(card);
        }

        if (!hasResults) {
            JLabel noDocsLabel = new JLabel("No verified documents found", SwingConstants.CENTER);
            noDocsLabel.setFont(new Font("Segoe UI", Font.ITALIC, 16));
            noDocsLabel.setForeground(Color.GRAY);

            jPanel1.setLayout(new BorderLayout());
            jPanel1.add(noDocsLabel, BorderLayout.CENTER);
        }

        jPanel1.revalidate();
        jPanel1.repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnSearch = new javax.swing.JButton();
        txtSearch = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        cardPanel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        btnViewAcceptedDoc = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));

        btnSearch.setBackground(new java.awt.Color(0, 51, 102));
        btnSearch.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        txtSearch.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        cardPanel.setBackground(new java.awt.Color(255, 255, 255));
        cardPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        javax.swing.GroupLayout cardPanelLayout = new javax.swing.GroupLayout(cardPanel);
        cardPanel.setLayout(cardPanelLayout);
        cardPanelLayout.setHorizontalGroup(
            cardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        cardPanelLayout.setVerticalGroup(
            cardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardPanelLayout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 327, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(cardPanel);

        btnViewAcceptedDoc.setBackground(new java.awt.Color(0, 153, 0));
        btnViewAcceptedDoc.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnViewAcceptedDoc.setForeground(new java.awt.Color(255, 255, 255));
        btnViewAcceptedDoc.setText("View Document");
        btnViewAcceptedDoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAcceptedDocActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addComponent(btnViewAcceptedDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(380, 380, 380)
                                .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 971, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnSearch)
                    .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnViewAcceptedDoc)
                .addGap(16, 16, 16))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        // Check if search text is empty
        String searchText = (txtSearch != null ? txtSearch.getText().trim() : "");

        if (searchText.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a search input!",
                    "No Input",
                    JOptionPane.WARNING_MESSAGE);
            if (txtSearch != null) {
                txtSearch.requestFocus();
            }
            return;
        }
        loadVerifiedDocumentsWithSearch(searchText);
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnViewAcceptedDocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAcceptedDocActionPerformed
        if (selectedDriverId == -1) {
            JOptionPane.showMessageDialog(this,
                    "Please select a driver from the list first.",
                    "No Selection",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseHelper.getConnection()) {
            String sql = "SELECT pdf_name, License_pdf FROM Transport WHERE Driver_ID = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, selectedDriverId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String pdfName = rs.getString("pdf_name");
                Blob pdfBlob = rs.getBlob("License_pdf");

                if (pdfBlob == null) {
                    JOptionPane.showMessageDialog(this,
                            "No PDF file found for this driver.",
                            "File Not Found",
                            JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Create temp file
                File pdfFile = new File(System.getProperty("java.io.tmpdir"), pdfName);

                // Write blob to file
                try (InputStream in = pdfBlob.getBinaryStream(); FileOutputStream out = new FileOutputStream(pdfFile)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = in.read(buffer)) != -1) {
                        out.write(buffer, 0, bytesRead);
                    }
                }

                // Open the PDF file
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(pdfFile);
                } else {
                    JOptionPane.showMessageDialog(this,
                            "Cannot open PDF. Desktop operations not supported.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this,
                        "File not found for selected driver.",
                        "Not Found",
                        JOptionPane.WARNING_MESSAGE);
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Error opening file: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnViewAcceptedDocActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnViewAcceptedDoc;
    private javax.swing.JPanel cardPanel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
