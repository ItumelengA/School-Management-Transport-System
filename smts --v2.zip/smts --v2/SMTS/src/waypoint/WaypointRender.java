/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package waypoint;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import javax.swing.JButton;
import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.viewer.WaypointPainter;

public class WaypointRender extends WaypointPainter<MyWaypoint> {

    @Override
    protected void doPaint(Graphics2D g, JXMapViewer map, int width, int height) {
        for (MyWaypoint wp : getWaypoints()) {
            Point2D p = map.getTileFactory().geoToPixel(wp.getPosition(), map.getZoom());
            Rectangle rec = map.getViewportBounds();
            int x = (int) (p.getX() - rec.getX());
            int y = (int) (p.getY() - rec.getY());
            JButton button = wp.getButton();
            if (button != null) {
                button.setLocation(x - button.getWidth() / 2, y - button.getHeight());
            }

            // Draw a pin/marker shape
            g.setColor(Color.RED);

            // Draw circle for the pin head
            int pinSize = 20;
            g.fillOval(x - pinSize / 2, y - pinSize, pinSize, pinSize);

            // Draw triangle for pin point
            int[] xPoints = {x - 8, x + 8, x};
            int[] yPoints = {y - pinSize, y - pinSize, y};
            g.fillPolygon(xPoints, yPoints, 3);

            // Draw white center dot
            g.setColor(Color.WHITE);
            g.fillOval(x - 5, y - pinSize + 5, 10, 10);
        }
    }
}