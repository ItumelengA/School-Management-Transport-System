
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class DriverProfile extends javax.swing.JPanel {

    private Driver loggedInDriver;

    public DriverProfile(int loginId) {
        initComponents();
        loadDriverInfo(loginId);

    }

    public void setLoggedInDriver(Driver driver) {
        this.loggedInDriver = driver;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        btnEditProfile = new javax.swing.JButton();
        btnUpload = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        lblCharge = new javax.swing.JLabel();
        lblTimeAfternoon = new javax.swing.JLabel();
        lblTimeMorning = new javax.swing.JLabel();
        lblSchool = new javax.swing.JLabel();
        lblPhone = new javax.swing.JLabel();
        lblSurname = new javax.swing.JLabel();
        lblName = new javax.swing.JLabel();
        lblLicenseNumber = new javax.swing.JLabel();
        lblMake = new javax.swing.JLabel();
        lblModel = new javax.swing.JLabel();
        lblYear = new javax.swing.JLabel();
        lblReg = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        jPanel3.setForeground(new java.awt.Color(153, 153, 153));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/profile_image_d.png"))); // NOI18N

        btnEditProfile.setBackground(new java.awt.Color(0, 153, 0));
        btnEditProfile.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnEditProfile.setForeground(new java.awt.Color(255, 255, 255));
        btnEditProfile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/edit_icon.png"))); // NOI18N
        btnEditProfile.setText("Edit Info");
        btnEditProfile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditProfileActionPerformed(evt);
            }
        });

        btnUpload.setBackground(new java.awt.Color(0, 153, 0));
        btnUpload.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnUpload.setForeground(new java.awt.Color(255, 255, 255));
        btnUpload.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/upload.png"))); // NOI18N
        btnUpload.setText("Upload ");
        btnUpload.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUploadActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("Name:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Surname:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Phone number:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("School Name:");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Time morning:");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Time afternoon:");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(102, 102, 102));
        jLabel8.setText("Amount charge per month R:");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("License number:");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("Vehicle make:");

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("Vehicle model:");

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("Vehicle year:");

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("Vehicle registration:");

        lblCharge.setText("--");

        lblTimeAfternoon.setText("--");

        lblTimeMorning.setText("--");

        lblSchool.setText("--");

        lblPhone.setText("--");

        lblSurname.setText("--");

        lblName.setText("--");

        lblLicenseNumber.setText("--");

        lblMake.setText("--");

        lblModel.setText("--");

        lblYear.setText("--");

        lblReg.setText("--");

        jLabel26.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(51, 153, 255));
        jLabel26.setText("Transport Information");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(118, 118, 118)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jSeparator2)
                            .addComponent(jSeparator1)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblSchool))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblTimeMorning))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(18, 18, 18)
                                .addComponent(lblTimeAfternoon))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel1))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblName)
                                    .addComponent(lblSurname)
                                    .addComponent(lblPhone))))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(145, 145, 145)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel13)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(lblReg))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel9)
                                            .addComponent(jLabel10)
                                            .addComponent(jLabel11)
                                            .addComponent(jLabel12))
                                        .addGap(37, 37, 37)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lblYear)
                                            .addComponent(lblModel)
                                            .addComponent(lblMake)
                                            .addComponent(lblLicenseNumber)))))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel26)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                            .addComponent(btnEditProfile, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(50, 50, 50)
                                            .addComponent(btnUpload, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(lblCharge))))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(142, 142, 142)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(422, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addComponent(jLabel26)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel9)
                    .addComponent(lblName)
                    .addComponent(lblLicenseNumber))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel10)
                    .addComponent(lblSurname)
                    .addComponent(lblMake))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel11)
                    .addComponent(lblPhone)
                    .addComponent(lblModel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel12)
                    .addComponent(lblSchool)
                    .addComponent(lblYear))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel13)
                    .addComponent(lblTimeMorning)
                    .addComponent(lblReg))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(lblTimeAfternoon))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 4, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(lblCharge))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEditProfile)
                    .addComponent(btnUpload, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(98, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        add(jPanel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void btnEditProfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditProfileActionPerformed
        // Verify driver is loaded
        if (loggedInDriver == null) {
            JOptionPane.showMessageDialog(this, "Driver information not loaded. Please try logging in again.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Create input fields pre-filled with current data
        JTextField txtName = new JTextField(lblName.getText());
        JTextField txtSurname = new JTextField(lblSurname.getText());
        JTextField txtPhone = new JTextField(lblPhone.getText());
        JTextField txtSchool = new JTextField(lblSchool.getText());
        JTextField txtTimeMorning = new JTextField(lblTimeMorning.getText());
        JTextField txtTimeAfternoon = new JTextField(lblTimeAfternoon.getText());
        JTextField txtCharge = new JTextField(lblCharge.getText());

        JTextField txtLicenseNumber = new JTextField(lblLicenseNumber.getText());
        JTextField txtMake = new JTextField(lblMake.getText());
        JTextField txtModel = new JTextField(lblModel.getText());
        JTextField txtYear = new JTextField(lblYear.getText());
        JTextField txtReg = new JTextField(lblReg.getText());

        // Create message array for JOptionPane
        Object[] message = {
            "Name:", txtName,
            "Surname:", txtSurname,
            "Phone Number:", txtPhone,
            "School Name:", txtSchool,
            "Time Morning:", txtTimeMorning,
            "Time Afternoon:", txtTimeAfternoon,
            "Charge (R):", txtCharge,
            "License Number:", txtLicenseNumber,
            "Vehicle Make:", txtMake,
            "Vehicle Model:", txtModel,
            "Vehicle Year:", txtYear,
            "Vehicle Registration:", txtReg
        };

        int option = JOptionPane.showConfirmDialog(
                this,
                message,
                "Edit Driver Information",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (option == JOptionPane.OK_OPTION) {
            try (Connection conn = DatabaseHelper.getConnection()) {
                // Update driver_registrations using Driver_ID (not Login_ID)
                String sqlDriver = "UPDATE driver_registrations SET Name=?, Surname=?, Phone_number=?, "
                        + "School_name=?, Time_morning=?, Time_afternoon=?, Charge_amount_R=? WHERE Driver_ID=?";
                PreparedStatement stmtDriver = conn.prepareStatement(sqlDriver);
                stmtDriver.setString(1, txtName.getText());
                stmtDriver.setString(2, txtSurname.getText());
                stmtDriver.setString(3, txtPhone.getText());
                stmtDriver.setString(4, txtSchool.getText());
                stmtDriver.setString(5, txtTimeMorning.getText());
                stmtDriver.setString(6, txtTimeAfternoon.getText());
                stmtDriver.setDouble(7, Double.parseDouble(txtCharge.getText()));
                stmtDriver.setInt(8, loggedInDriver.getDriverId());
                stmtDriver.executeUpdate();

                // Update Transport table using Driver_ID (not Login_ID)
                String sqlTransport = "UPDATE Transport SET License_number=?, Vehicle_make=?, Vehicle_model=?, "
                        + "Vehicle_year=?, Vehicle_registration=? WHERE Driver_ID=?";
                PreparedStatement stmtTransport = conn.prepareStatement(sqlTransport);
                stmtTransport.setString(1, txtLicenseNumber.getText());
                stmtTransport.setString(2, txtMake.getText());
                stmtTransport.setString(3, txtModel.getText());
                stmtTransport.setInt(4, Integer.parseInt(txtYear.getText()));
                stmtTransport.setString(5, txtReg.getText());
                stmtTransport.setInt(6, loggedInDriver.getDriverId());
                stmtTransport.executeUpdate();

                JOptionPane.showMessageDialog(this, "Profile updated successfully!");

                // Refresh labels on the panel
                lblName.setText(txtName.getText());
                lblSurname.setText(txtSurname.getText());
                lblPhone.setText(txtPhone.getText());
                lblSchool.setText(txtSchool.getText());
                lblTimeMorning.setText(txtTimeMorning.getText());
                lblTimeAfternoon.setText(txtTimeAfternoon.getText());
                lblCharge.setText(txtCharge.getText());
                lblLicenseNumber.setText(txtLicenseNumber.getText());
                lblMake.setText(txtMake.getText());
                lblModel.setText(txtModel.getText());
                lblYear.setText(txtYear.getText());
                lblReg.setText(txtReg.getText());

            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error updating profile: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnEditProfileActionPerformed

    private void btnUploadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUploadActionPerformed

        if (loggedInDriver == null) {
            JOptionPane.showMessageDialog(this, "Driver information not loaded. Please try logging in again.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JFileChooser chooser = new JFileChooser();
        int result = chooser.showOpenDialog(this);

        if (result == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();

            try (FileInputStream fis = new FileInputStream(file); Connection conn = DatabaseHelper.getConnection()) {
               
                String sql = "UPDATE Transport SET License_pdf=?, pdf_name=?, Status='Pending', Rejected_reason=NULL "
                        + "WHERE Driver_ID=?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setBinaryStream(1, fis, (int) file.length());
                stmt.setString(2, file.getName());
                stmt.setInt(3, loggedInDriver.getDriverId()); // Use Driver_ID directly
                stmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "License uploaded successfully!");
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error uploading file: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnUploadActionPerformed
    private void loadDriverInfo(int loginId) {     

       Driver driver = DatabaseHelper.getDriverByID(loginId);

        if (driver != null) {
            this.loggedInDriver = driver;
         
            lblName.setText(driver.getFirstName());
            lblSurname.setText(driver.getSurname());
            lblPhone.setText(driver.getPhone_number());
            lblSchool.setText(driver.getSchoolName());
            lblTimeMorning.setText(driver.getTime_morning() != null ? driver.getTime_morning() : "--");
            lblTimeAfternoon.setText(driver.getTime_afternoon() != null ? driver.getTime_afternoon() : "--");
            lblCharge.setText(String.valueOf(driver.getRate()));

            lblLicenseNumber.setText(driver.getLicenseNumber() != null ? driver.getLicenseNumber() : "--");
            lblMake.setText(driver.getVehicleMake() != null ? driver.getVehicleMake() : "--");
            lblModel.setText(driver.getVehicleModel() != null ? driver.getVehicleModel() : "--");
            lblYear.setText(driver.getVehicleYear() != 0 ? String.valueOf(driver.getVehicleYear()) : "--");
            lblReg.setText(driver.getVehicleRegistration() != null ? driver.getVehicleRegistration() : "--");
        } else {           
            JOptionPane.showMessageDialog(this, "Driver details not found for Login ID: " + loginId,
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditProfile;
    private javax.swing.JButton btnUpload;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lblCharge;
    private javax.swing.JLabel lblLicenseNumber;
    private javax.swing.JLabel lblMake;
    private javax.swing.JLabel lblModel;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblPhone;
    private javax.swing.JLabel lblReg;
    private javax.swing.JLabel lblSchool;
    private javax.swing.JLabel lblSurname;
    private javax.swing.JLabel lblTimeAfternoon;
    private javax.swing.JLabel lblTimeMorning;
    private javax.swing.JLabel lblYear;
    // End of variables declaration//GEN-END:variables
}
