
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;


public class ManageregisteredUsers extends javax.swing.JPanel {

    public ManageregisteredUsers() {
        initComponents();
        loadUsers();

    }

    private void loadUsers() {
        DefaultTableModel model = new DefaultTableModel(new String[]{
            "Login_ID", "Email", "User Role", "Created At", "Account status"
        }, 0);

        try (Connection conn = DatabaseHelper.getConnection()) {
            String sql = "SELECT Login_ID, Email, User_role, Created_at,Account_status FROM Login";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("Login_ID"),
                    rs.getString("Email"),
                    rs.getString("User_role"),
                    rs.getTimestamp("Created_at"),
                    rs.getString("Account_status")
                });
            }

            jTable1.setModel(model);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading users: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtSearchBar = new javax.swing.JTextField();
        btnSerach = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        btnRestore = new javax.swing.JButton();
        btnBlock = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        btnSerach.setBackground(new java.awt.Color(0, 102, 204));
        btnSerach.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnSerach.setForeground(new java.awt.Color(255, 255, 255));
        btnSerach.setText("Search");
        btnSerach.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSerachActionPerformed(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Login_ID", "Email", "User Role", "Created At", "Account status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setPreferredSize(new java.awt.Dimension(300, 300));
        jScrollPane2.setViewportView(jTable1);

        btnDelete.setBackground(new java.awt.Color(0, 153, 0));
        btnDelete.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnDelete.setForeground(new java.awt.Color(255, 255, 255));
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnRestore.setBackground(new java.awt.Color(0, 102, 204));
        btnRestore.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnRestore.setForeground(new java.awt.Color(255, 255, 255));
        btnRestore.setText("Restore");
        btnRestore.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRestoreActionPerformed(evt);
            }
        });

        btnBlock.setBackground(new java.awt.Color(0, 153, 0));
        btnBlock.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnBlock.setForeground(new java.awt.Color(255, 255, 255));
        btnBlock.setText("Block");
        btnBlock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBlockActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(120, 120, 120)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(258, 258, 258)
                        .addComponent(btnSerach, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtSearchBar, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 814, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(106, 106, 106)
                        .addComponent(btnBlock, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(111, 111, 111)
                        .addComponent(btnRestore, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtSearchBar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSerach, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDelete)
                    .addComponent(btnRestore)
                    .addComponent(btnBlock))
                .addContainerGap(48, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnSerachActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSerachActionPerformed
        String keyword = txtSearchBar.getText().trim();
        DefaultTableModel model = new DefaultTableModel(new String[]{
            "Login_ID", "Email", "User Role", "Created At","Account Status"
        }, 0);

        try (Connection conn = DatabaseHelper.getConnection()) {
            String sql = "SELECT Login_ID, Email, User_role, Created_at,Account_status "
                    + "FROM Login WHERE Email LIKE ? OR User_role LIKE ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, "%" + keyword + "%");
            pst.setString(2, "%" + keyword + "%");
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("Login_ID"),
                    rs.getString("Email"),
                    rs.getString("User_role"),
                    rs.getTimestamp("Created_at"),
                    rs.getString("Account_status")
                });
            }

        jTable1.setModel(model);
    }
    catch (SQLException e

    
        ) {
            JOptionPane.showMessageDialog(this, "Search Error: " + e.getMessage());
    }
    }//GEN-LAST:event_btnSerachActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        int row = jTable1.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a user to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int loginId = Integer.parseInt(jTable1.getValueAt(row, 0).toString());
        String name = jTable1.getValueAt(row, 1).toString();

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to permanently delete all information related to " + name + "?",
                "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseHelper.getConnection(); PreparedStatement ps = conn.prepareStatement("DELETE FROM Login WHERE Login_ID = ?")) {
                ps.setInt(1, loginId);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "User and related data deleted successfully!");
                refreshTable();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting user: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnDeleteActionPerformed
    private void refreshTable() {
    DefaultTableModel model = new DefaultTableModel(new String[]{
        "Login_ID", "Email", "User Role", "Created At", "Account status"
    }, 0);

    try (Connection conn = DatabaseHelper.getConnection()) {
        String sql = "SELECT Login_ID, Email, User_role, Created_at,Account_status FROM Login";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("Login_ID"),
                rs.getString("Email"),
                rs.getString("User_role"),
                rs.getTimestamp("Created_at"),
                rs.getString("Account_status")
            });
        }

        jTable1.setModel(model);

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error loading users: " + e.getMessage());
    }
}

    private void btnRestoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRestoreActionPerformed
        int row = jTable1.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a user to restore.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int loginId = Integer.parseInt(jTable1.getValueAt(row, 0).toString());
        String email = jTable1.getValueAt(row, 1).toString();

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to restore the user: " + email + "?",
                "Confirm Restore", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseHelper.getConnection(); PreparedStatement ps = conn.prepareStatement(
                    "UPDATE Login SET Account_status = 'Active' WHERE Login_ID = ?")) {

                ps.setInt(1, loginId);
                int updated = ps.executeUpdate();

                if (updated > 0) {
                    JOptionPane.showMessageDialog(this, "User has been restored successfully.");
                    refreshTable(); // Reload table to show updated status
                } else {
                    JOptionPane.showMessageDialog(this, "No user found with the selected ID.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error restoring user: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnRestoreActionPerformed

    private void btnBlockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBlockActionPerformed
        int row = jTable1.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a user to block.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int loginId = Integer.parseInt(jTable1.getValueAt(row, 0).toString());
        String email = jTable1.getValueAt(row, 1).toString();

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to block the user: " + email + "?",
                "Confirm Block", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseHelper.getConnection(); PreparedStatement ps = conn.prepareStatement(
                    "UPDATE Login SET Account_status = 'Blocked' WHERE Login_ID = ?")) {

                ps.setInt(1, loginId);
                int updated = ps.executeUpdate();

                if (updated > 0) {
                    JOptionPane.showMessageDialog(this, "User has been blocked successfully.");
                    refreshTable(); // Reload table to show updated status
                } else {
                    JOptionPane.showMessageDialog(this, "No user found with the selected ID.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error blocking user: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnBlockActionPerformed
    private void updateStatus(String fullName, String newStatus) {
    try (Connection conn = DatabaseHelper.getConnection()) {
        String sql = "UPDATE login_accounts SET status=? WHERE full_name=?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, newStatus);
        pst.setString(2, fullName);
        pst.executeUpdate();
        JOptionPane.showMessageDialog(this, "Status updated to " + newStatus);
        loadUsers();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Update Error: " + e.getMessage());
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBlock;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnRestore;
    private javax.swing.JButton btnSerach;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtSearchBar;
    // End of variables declaration//GEN-END:variables
}
