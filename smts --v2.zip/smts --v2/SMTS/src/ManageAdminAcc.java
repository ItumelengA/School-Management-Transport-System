
import javax.swing.*;
import java.sql.*;
import java.awt.event.ActionEvent;

public class ManageAdminAcc extends javax.swing.JPanel {

    private int currentAdminId = 1;

    public ManageAdminAcc() {
        initComponents();
        loadAdminData();
    }

    private void loadAdminData() {
        try (Connection conn = DatabaseHelper.getConnection(); PreparedStatement pst = conn.prepareStatement(
                "SELECT aa.full_name, aa.phone, aa.username, l.Email, l.User_role "
                + "FROM admin_accounts AS aa "
                + "JOIN Login AS l ON aa.Login_ID = l.Login_ID "
                + "WHERE aa.admin_id = ?")) {

            pst.setInt(1, currentAdminId);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                txtFullName.setText(rs.getString("full_name"));
                txtEmail.setText(rs.getString("Email"));
                txtPhone.setText(rs.getString("phone"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading admin data: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        btnResetLog = new javax.swing.JButton();
        jSeparator7 = new javax.swing.JSeparator();
        btnEditProfile = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        txtFullName = new javax.swing.JTextField();
        txtPhone = new javax.swing.JTextField();
        txtFullName3 = new javax.swing.JTextField();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(null);
        setPreferredSize(new java.awt.Dimension(810, 396));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 217, 223), 1, true));

        jSeparator3.setMinimumSize(new java.awt.Dimension(100, 200));
        jSeparator3.setPreferredSize(new java.awt.Dimension(500, 100));

        jSeparator4.setMinimumSize(new java.awt.Dimension(100, 200));
        jSeparator4.setPreferredSize(new java.awt.Dimension(500, 100));

        jSeparator5.setMinimumSize(new java.awt.Dimension(100, 200));
        jSeparator5.setPreferredSize(new java.awt.Dimension(500, 100));

        jSeparator6.setMinimumSize(new java.awt.Dimension(100, 200));
        jSeparator6.setPreferredSize(new java.awt.Dimension(500, 100));

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("Manage Profile");

        btnResetLog.setBackground(new java.awt.Color(0, 102, 204));
        btnResetLog.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnResetLog.setForeground(new java.awt.Color(255, 255, 255));
        btnResetLog.setText("Reset Login Credentials");
        btnResetLog.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetLogActionPerformed(evt);
            }
        });

        jSeparator7.setMinimumSize(new java.awt.Dimension(100, 200));
        jSeparator7.setPreferredSize(new java.awt.Dimension(500, 100));

        btnEditProfile.setBackground(new java.awt.Color(0, 153, 0));
        btnEditProfile.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        btnEditProfile.setForeground(new java.awt.Color(255, 255, 255));
        btnEditProfile.setText("Edit Profile");
        btnEditProfile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditProfileActionPerformed(evt);
            }
        });

        jLabel2.setText("Full name:");

        jLabel3.setText("Email Address:");

        jLabel4.setText("Phone Number:");

        jLabel5.setText("Change Password:");

        txtEmail.setBorder(null);

        txtFullName.setBorder(null);

        txtPhone.setBorder(null);

        txtFullName3.setText("*************************");
        txtFullName3.setBorder(null);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(130, 130, 130)
                            .addComponent(jLabel1))
                        .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(375, 375, 375)
                            .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(20, 20, 20)
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtFullName, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(30, 30, 30)
                            .addComponent(btnEditProfile, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(20, 20, 20)
                            .addComponent(btnResetLog, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(21, 21, 21)
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtEmail)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtPhone))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtFullName3, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(27, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addGap(11, 11, 11)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtFullName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 6, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtFullName3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnEditProfile)
                    .addComponent(btnResetLog))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 120, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void btnResetLogActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetLogActionPerformed
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JPasswordField txtCurrentPassword = new JPasswordField(20);
        JPasswordField txtNewPassword = new JPasswordField(20);
        JPasswordField txtConfirmPassword = new JPasswordField(20);

        panel.add(new JLabel("Current Password:"));
        panel.add(txtCurrentPassword);
        panel.add(Box.createVerticalStrut(10));
        panel.add(new JLabel("New Password:"));
        panel.add(txtNewPassword);
        panel.add(Box.createVerticalStrut(10));
        panel.add(new JLabel("Confirm New Password:"));
        panel.add(txtConfirmPassword);

        int result = JOptionPane.showConfirmDialog(this, panel, "Reset Login Credentials",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String currentPassword = new String(txtCurrentPassword.getPassword());
            String newPassword = new String(txtNewPassword.getPassword());
            String confirmPassword = new String(txtConfirmPassword.getPassword());

            if (currentPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required!");
                return;
            }

            if (!newPassword.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(this, "New passwords do not match!");
                return;
            }

            if (newPassword.length() < 6) {
                JOptionPane.showMessageDialog(this, "Password must be at least 6 characters long!");
                return;
            }

            try (Connection conn = DatabaseHelper.getConnection(); PreparedStatement pst = conn.prepareStatement(
                    "SELECT l.Password FROM Login l "
                    + "JOIN admin_accounts aa ON aa.Login_ID = l.Login_ID "
                    + "WHERE aa.admin_id = ?")) {

                pst.setInt(1, currentAdminId);
                ResultSet rs = pst.executeQuery();

                if (rs.next()) {
                    String storedPassword = rs.getString("Password");

                    if (!currentPassword.equals(storedPassword)) {
                        JOptionPane.showMessageDialog(this, "Current password is incorrect!");
                        return;
                    }

                    try (PreparedStatement updatePst = conn.prepareStatement(
                            "UPDATE Login SET Password = ? WHERE Login_ID = "
                            + "(SELECT Login_ID FROM admin_accounts WHERE admin_id = ?)")) {

                        updatePst.setString(1, newPassword); // ⚠️ Ideally hash this
                        updatePst.setInt(2, currentAdminId);

                        int rowsUpdated = updatePst.executeUpdate();
                        if (rowsUpdated > 0) {
                            JOptionPane.showMessageDialog(this, "Password updated successfully!");
                        } else {
                            JOptionPane.showMessageDialog(this, "Password update failed!");
                        }
                    }
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error updating password: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnResetLogActionPerformed

    private void btnEditProfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditProfileActionPerformed
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JTextField txtNewFullName = new JTextField(txtFullName.getText(), 20);
        JTextField txtNewEmail = new JTextField(txtEmail.getText(), 20);
        JTextField txtNewPhone = new JTextField(txtPhone.getText(), 20);

        panel.add(new JLabel("Full Name:"));
        panel.add(txtNewFullName);
        panel.add(Box.createVerticalStrut(10));
        panel.add(new JLabel("Email Address:"));
        panel.add(txtNewEmail);
        panel.add(Box.createVerticalStrut(10));
        panel.add(new JLabel("Phone Number:"));
        panel.add(txtNewPhone);

        int result = JOptionPane.showConfirmDialog(this, panel, "Edit Profile",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String newFullName = txtNewFullName.getText().trim();
            String newEmail = txtNewEmail.getText().trim();
            String newPhone = txtNewPhone.getText().trim();

            if (newFullName.isEmpty() || newEmail.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Full name and email cannot be empty!");
                return;
            }

            if (!newEmail.contains("@")) {
                JOptionPane.showMessageDialog(this, "Please enter a valid email address!");
                return;
            }

            try (Connection conn = DatabaseHelper.getConnection()) {
                conn.setAutoCommit(false); // Start transaction

                try (PreparedStatement pst1 = conn.prepareStatement(
                        "UPDATE admin_accounts SET full_name = ?, phone = ? WHERE admin_id = ?")) {
                    pst1.setString(1, newFullName);
                    pst1.setString(2, newPhone);
                    pst1.setInt(3, currentAdminId);
                    pst1.executeUpdate();
                }

                try (PreparedStatement pst2 = conn.prepareStatement(
                        "UPDATE Login SET Email = ? WHERE Login_ID = "
                        + "(SELECT Login_ID FROM admin_accounts WHERE admin_id = ?)")) {
                    pst2.setString(1, newEmail);
                    pst2.setInt(2, currentAdminId);
                    pst2.executeUpdate();
                }

                conn.commit();
                JOptionPane.showMessageDialog(this, "Profile updated successfully!");
                loadAdminData(); // Refresh displayed data
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error updating profile: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnEditProfileActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditProfile;
    private javax.swing.JButton btnResetLog;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtFullName;
    private javax.swing.JTextField txtFullName3;
    private javax.swing.JTextField txtPhone;
    // End of variables declaration//GEN-END:variables
}
