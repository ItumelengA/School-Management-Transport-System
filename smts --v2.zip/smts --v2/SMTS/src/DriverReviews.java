
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DriverReviews extends javax.swing.JPanel {

    public DriverReviews() {
        initComponents();
        String name = txtDriverName.getText().trim();
        loadDriverReviews(name);
    }

    public void loadDriverReviews(String name) {
        if (name == null || name.isEmpty()) {
            jLabel2.setText("No driver logged in");
            return;
        }

        System.out.println("Loading reviews for driver: " + name);

        jPanel2.removeAll();
        jPanel2.setLayout(new BoxLayout(jPanel2, BoxLayout.Y_AXIS));

        int count = 0;

        String query = "SELECT Parent_Name, Comment, Review_Date FROM reviews WHERE Driver_Name = ? ORDER BY Review_Date DESC";

        try (Connection conn = DatabaseHelper.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                count++;

                String parentName = rs.getString("Parent_Name");
                String comment = rs.getString("Comment");
                Timestamp date = rs.getTimestamp("Review_Date");

                if (comment == null || comment.trim().isEmpty()) {
                    comment = "No comment provided.";
                }

                // 🔹 Card UI
                JPanel card = new JPanel() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        Graphics2D g2 = (Graphics2D) g;
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                        g2.setColor(new Color(200, 200, 200, 150));
                        g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);

                        g2.setColor(Color.WHITE);
                        g2.fillRoundRect(0, 0, getWidth() - 10, getHeight() - 10, 20, 20);
                    }
                };
                card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
                card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
                card.setOpaque(false);
                card.setMaximumSize(new Dimension(600, 120));
                card.setAlignmentX(Component.LEFT_ALIGNMENT);

                // 🔹 Parent Name
                JLabel lblParent = new JLabel("Parent: " + parentName);
                lblParent.setFont(new Font("Segoe UI", Font.BOLD, 14));
                lblParent.setForeground(new Color(51, 51, 51));

                // 🔹 Comment
                JLabel lblComment = new JLabel("<html><body style='width:500px'>" + comment + "</body></html>");
                lblComment.setForeground(new Color(80, 80, 80));

                // 🔹 Date (optional)
                JLabel lblDate = new JLabel("Date: " + date.toString());
                lblDate.setFont(new Font("Segoe UI", Font.ITALIC, 11));
                lblDate.setForeground(new Color(120, 120, 120));

                // Add components
                card.add(lblParent);
                card.add(Box.createVerticalStrut(5));
                card.add(lblComment);
                card.add(Box.createVerticalStrut(8));
                card.add(lblDate);

                jPanel2.add(card);
                jPanel2.add(Box.createVerticalStrut(15)); // spacing between cards
            }

            // Header message
            if (count == 0) {
                jLabel2.setText("No reviews yet.");
            } else {
                jLabel2.setText("Reviews (" + count + ")");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            jLabel2.setText("Error loading reviews.");
        }

        jPanel2.revalidate();
        jPanel2.repaint();

        System.out.println("Reviews loaded and panel refreshed!");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtDriverName = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        btnSearch = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial Black", 2, 14)); // NOI18N
        jLabel1.setText("Driver reviews");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(284, 0, 163, -1));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 668, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 353, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(jPanel2);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 101, 624, 301));

        jLabel2.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel2.setText("Total: ---");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(617, 73, -1, -1));
        add(txtDriverName, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 67, 180, 30));

        jLabel3.setText("Name");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 45, -1, -1));

        btnSearch.setBackground(new java.awt.Color(0, 0, 153));
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });
        add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 68, 80, 30));
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        String name = txtDriverName.getText().trim();
        loadDriverReviews(name);
    }//GEN-LAST:event_btnSearchActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearch;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtDriverName;
    // End of variables declaration//GEN-END:variables
}
